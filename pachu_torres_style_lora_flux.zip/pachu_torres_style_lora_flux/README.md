---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-08_19-27-36.png
  text: >-
    Training With LoRA: Pachu Torres style, this image powerfully portrays a romantic moment between a man and a woman, the scene captures an intimate embrace, with the couple kissing. the woman's arms tightly wrap around the man's neck. the woman's standing on one leg, the other leg wrap around the man's leg. the man lifts up the woman's red dress and grabs her ass. The woman is not wearing underwear. the man wears shirt and pants. The composition prioritizes the connection between them, drawing the viewer's focus directly to their affection. the background is set against a light blue background punctuated with splashes of green and red. The simplicity of the background and muted color palette contribute to a feeling of closeness and intimacy, creating a relatable and emotionally resonant depiction of love. The overall effect is a personal and touching portrayal of connection and affection.
- output:
    url: images/2026-01-08_19-32-25.png
  text: >-
    Training With LoRA: Pachu Torres style, this image portrays a playful and flirty scene of a woman enjoying a carefree moment. She's depicted with long, dark hair cascading down her shoulder, wearing a vibrant green bikini top with delicate straps. She is not wearing bra as her nipples with piercing are visible. Her hands are actively adjusting the thin, likely nylon or spandex, panty straps. Noticeable details include her slender fingers adorned with bright pink nail polish. The background is a clean, solid light blue, providing a simple backdrop that emphasizes the woman and her playful pose. The bright colors and cartoon style contribute to a lighthearted and humorous tone, suggesting a sunny and enjoyable experience.
- output:
    url: images/2026-01-08_19-35-29.png
  text: >-
    Training With LoRA: Pachu Torres style, the image portrays a romantic scene featuring a man and woman in a tender moment. The man, sporting a white tank top,blue jeans and helmet, gently pulls down the woman's panty. The woman is seated on a black motorcycle, wearing a pink dress and with long, dark hair. Her boob and nipple is visible. The composition suggests a loving relationship between the couple, with the panty pulling gesture emphasizing their connection. The motorcycle introduces an element of adventure and freedom to the scene. The overall atmosphere is intimate and affectionate, conveying a sense of closeness and shared experience. The image evokes feelings of love and a shared journey, blending romance with a touch of rebellious spirit.
- output:
    url: images/2026-01-08_19-49-30.png
  text: >-
    Training With LoRA: Pachu Torres style, this image captures a woman with vibrant blue hair, orange mask, seated on a green surface and clad in black straps. She holds a chain in her hand, contributing to a palpable sense of restraint. the chain connects to her black choker on the neck. Her nipples are visible. Beside her sits a carved pumpkin for Halloween. The overall tone is dark and mysterious, evoking a feeling of foreboding and suspense. The composition suggests a narrative of captivity or restriction, with the chains hinting at a potential holding situation. The carved pumpkin adds a distinct element of horror, intensifying the feeling of unease. The image focuses on themes of confinement and control, leaving the viewer with a lingering sense of tension and a feeling that something ominous is about to unfold.
- output:
    url: images/2026-01-08_19-54-20.png
  text: >-
    Training With LoRA: Pachu Torres style, this image portrays a tender, romantic moment between a woman and a man embracing in a loving kiss. the woman sitting on top is biting the man's chin with her eyes closed. the man lying on his back beneath the woman close his eyes as he is enjoying. The iamge utilizes a predominantly purple color scheme, accented with soft pinks in the background, creating a warm and intimate atmosphere. The composition is simple and central, focusing viewer attention directly on their connection. Soft, diffused lighting and subtle shadows add depth and dimension, enhancing the overall feeling of affection and intimacy. The minimalistic background further emphasizes the emotional core of the scene, conveying a powerful sense of love and connection.
- output:
    url: images/2026-01-08_19-55-38.png
  text: >-
    Training With LoRA: Pachu Torres style, the image focusing on a woman's torso, evoking a feeling of intimacy and sensuality. The woman's body is stylized with bold lines and a striking deep red skin tone. She wears a bright yellow camisole, the sunny hue contrasting sharply with her skin. The shirt is pulled upwards by her hands, revealing a glimpse of her midriff and creating a sense of exposure and vulnerability. The lack of visible hair focuses attention on the torso and the suggestive pose. The vibrant colors and bold lines contribute to a dynamic and attention-grabbing composition, amplifying the overall feeling of intimacy and a playful, suggestive atmosphere.
- output:
    url: images/2026-01-08_20-03-42.png
  text: >-
    Training Without LoRA: Pachu Torres style, this image powerfully portrays a romantic moment between a man and a woman, the scene captures an intimate embrace, with the couple kissing. the woman's arms tightly wrap around the man's neck. the woman's standing on one leg, the other leg wrap around the man's leg. the man lifts up the woman's red dress and grabs her ass. The woman is not wearing underwear. the man wears shirt and pants. The composition prioritizes the connection between them, drawing the viewer's focus directly to their affection. the background is set against a light blue background punctuated with splashes of green and red. The simplicity of the background and muted color palette contribute to a feeling of closeness and intimacy, creating a relatable and emotionally resonant depiction of love. The overall effect is a personal and touching portrayal of connection and affection.
- output:
    url: images/2026-01-08_20-08-18.png
  text: >-
    Training Without LoRA: Pachu Torres style, this image portrays a playful and flirty scene of a woman enjoying a carefree moment. She's depicted with long, dark hair cascading down her shoulder, wearing a vibrant green bikini top with delicate straps. She is not wearing bra as her nipples with piercing are visible. Her hands are actively adjusting the thin, likely nylon or spandex, panty straps. Noticeable details include her slender fingers adorned with bright pink nail polish. The background is a clean, solid light blue, providing a simple backdrop that emphasizes the woman and her playful pose. The bright colors and cartoon style contribute to a lighthearted and humorous tone, suggesting a sunny and enjoyable experience.
- output:
    url: images/2026-01-08_20-11-13.png
  text: >-
    Training Without LoRA: Pachu Torres style, the image portrays a romantic scene featuring a man and woman in a tender moment. The man, sporting a white tank top,blue jeans and helmet, gently pulls down the woman's panty. The woman is seated on a black motorcycle, wearing a pink dress and with long, dark hair. Her boob and nipple is visible. The composition suggests a loving relationship between the couple, with the panty pulling gesture emphasizing their connection. The motorcycle introduces an element of adventure and freedom to the scene. The overall atmosphere is intimate and affectionate, conveying a sense of closeness and shared experience. The image evokes feelings of love and a shared journey, blending romance with a touch of rebellious spirit.
- output:
    url: images/2026-01-08_20-24-35.png
  text: >-
    Training Without LoRA: Pachu Torres style, this image captures a woman with vibrant blue hair, orange mask, seated on a green surface and clad in black straps. She holds a chain in her hand, contributing to a palpable sense of restraint. the chain connects to her black choker on the neck. Her nipples are visible. Beside her sits a carved pumpkin for Halloween. The overall tone is dark and mysterious, evoking a feeling of foreboding and suspense. The composition suggests a narrative of captivity or restriction, with the chains hinting at a potential holding situation. The carved pumpkin adds a distinct element of horror, intensifying the feeling of unease. The image focuses on themes of confinement and control, leaving the viewer with a lingering sense of tension and a feeling that something ominous is about to unfold.
- output:
    url: images/2026-01-08_20-29-11.png
  text: >-
    Training Without LoRA: Pachu Torres style, this image portrays a tender, romantic moment between a woman and a man embracing in a loving kiss. the woman sitting on top is biting the man's chin with her eyes closed. the man lying on his back beneath the woman close his eyes as he is enjoying. The iamge utilizes a predominantly purple color scheme, accented with soft pinks in the background, creating a warm and intimate atmosphere. The composition is simple and central, focusing viewer attention directly on their connection. Soft, diffused lighting and subtle shadows add depth and dimension, enhancing the overall feeling of affection and intimacy. The minimalistic background further emphasizes the emotional core of the scene, conveying a powerful sense of love and connection.
- output:
    url: images/2026-01-08_20-30-26.png
  text: >-
    Training Without LoRA: Pachu Torres style, the image focusing on a woman's torso, evoking a feeling of intimacy and sensuality. The woman's body is stylized with bold lines and a striking deep red skin tone. She wears a bright yellow camisole, the sunny hue contrasting sharply with her skin. The shirt is pulled upwards by her hands, revealing a glimpse of her midriff and creating a sense of exposure and vulnerability. The lack of visible hair focuses attention on the torso and the suggestive pose. The vibrant colors and bold lines contribute to a dynamic and attention-grabbing composition, amplifying the overall feeling of intimacy and a playful, suggestive atmosphere.
- output:
    url: images/2026-01-08_19-09-57.png
  text: >-
    Testing With LoRA: Pachu Torres style, the image portrays a woman in a bondage inspired outfit, a black bra and underwear set with fishnet stockings and high-heeled boots. she is seated on stairs. She holds silver chain links attached to her choker on the neck. her short brown hair with bangs framing her face. Stone walls and red-tinted windows create a dramatic backdrop. The artwork presents a bold and sensual depiction of individuality.
- output:
    url: images/2026-01-08_19-10-23.png
  text: >-
    Testing With LoRA: Pachu Torres style, the image portrays a romantic scene of a man and woman. The man, with short hair and a black shirt, stands behind the woman, embracing her with one hand on her waist and the other in her hair. the woman is blindfolded and bondaged by red ropes across her white dress. the woman has not worn bra as her nipples pop out the dress. her posture conveying total submission in his embrace. The overall mood is intimate and affectionate, suggesting a deep emotional connection between the couple.
- output:
    url: images/2026-01-08_19-10-49.png
  text: >-
    Testing With LoRA: Pachu Torres style, A woman washes her car with a yellow sponge on a gray gravel driveway, framed by lush greenery. The woman is viewed from her rear side. She's naked with her long dark hair flowing down her back. She has soap water dripping down her ass and thighs. A vibrant hedge wall and trees form a scenic backdrop. The scene evokes a sense of peaceful solitude and intimacy, capturing a quiet moment of relaxation amidst a beautiful natural setting.
- output:
    url: images/2026-01-08_19-17-12.png
  text: >-
    Testing Without LoRA: Pachu Torres style, the image portrays a woman in a bondage inspired outfit, a black bra and underwear set with fishnet stockings and high-heeled boots. she is seated on stairs. She holds silver chain links attached to her choker on the neck. her short brown hair with bangs framing her face. Stone walls and red-tinted windows create a dramatic backdrop. The artwork presents a bold and sensual depiction of individuality.
- output:
    url: images/2026-01-08_19-17-37.png
  text: >-
    Testing Without LoRA: Pachu Torres style, the image portrays a romantic scene of a man and woman. The man, with short hair and a black shirt, stands behind the woman, embracing her with one hand on her waist and the other in her hair. the woman is blindfolded and bondaged by red ropes across her white dress. the woman has not worn bra as her nipples pop out the dress. her posture conveying total submission in his embrace. The overall mood is intimate and affectionate, suggesting a deep emotional connection between the couple.
- output:
    url: images/2026-01-08_19-18-02.png
  text: >-
    Testing Without LoRA: Pachu Torres style, A woman washes her car with a yellow sponge on a gray gravel driveway, framed by lush greenery. The woman is viewed from her rear side. She's naked with her long dark hair flowing down her back. She has soap water dripping down her ass and thighs. A vibrant hedge wall and trees form a scenic backdrop. The scene evokes a sense of peaceful solitude and intimacy, capturing a quiet moment of relaxation amidst a beautiful natural setting.
instance_prompt: Pachu Torres Style, lora, flux
license: mit
base_model:
- black-forest-labs/FLUX.1-dev
---

# Pachu Torres Style Lora Flux

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

This a non-quantized version of [https://huggingface.co/je-suis-tm/pachu_torres_style_lora_flux_nf4](https://huggingface.co/je-suis-tm/pachu_torres_style_lora_flux_nf4) with fewer female body distortions. Both are trained on the same dataset. The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py). The training took 1 hour on A100 80GB with max VRAM consumption at 33GB. The inference consumes 35GB of VRAM. 


## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/pachu_torres_style"
export OUTPUT_DIR="/pvol/pachu_torres_style_lora_flux"
accelerate config default

accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="Pachu Torres style" \
  --caption_column="text" \
  --resolution=512 \
  --center_crop \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/pachu_torres_style_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "Pachu Torres style, A woman washes her car with a yellow sponge on a gray gravel driveway, framed by lush greenery. The woman is viewed from her rear side. She's naked with her long dark hair flowing down her back. She has soap water dripping down her ass and thighs. A vibrant hedge wall and trees form a scenic backdrop. The scene evokes a sense of peaceful solitude and intimacy, capturing a quiet moment of relaxation amidst a beautiful natural setting."

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("pachu_torres_style.png")
```

## Trigger words

You should use `Pachu Torres Style` to trigger the image generation.


## Download model


[Download](/je-suis-tm/pachu_torres_style_lora_flux_nf4/tree/main) them in the Files & versions tab.