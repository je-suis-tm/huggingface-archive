---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-28_00-12-44.png
  text: >-
    Training With QLoRA: Melanie Laurent, radiating sophistication, sits before a bookshelf in a warmly lit, intimate setting. Dressed in a beige coat with prominent buttons and a matching hat, she holds an open book in her lap, her eyes meeting the viewer's gaze. Her long blonde hair frames her face, contributing to an air of elegance. The composition focuses primarily on the woman, who dominates the frame, while a partially visible bookshelf adds depth to the scene. A single light source from the right creates a soft, cozy atmosphere, enhancing the vintage feel of her attire. The muted color palette and gentle lighting contribute to a sense of refinement and poise, evoking a feeling of exclusivity and quiet grace. The overall impression is one of timeless beauty and understated luxury.
- output:
    url: images/2026-01-28_00-19-14.png
  text: >-
    Training Without QLoRA: Melanie Laurent, radiating sophistication, sits before a bookshelf in a warmly lit, intimate setting. Dressed in a beige coat with prominent buttons and a matching hat, she holds an open book in her lap, her eyes meeting the viewer's gaze. Her long blonde hair frames her face, contributing to an air of elegance. The composition focuses primarily on the woman, who dominates the frame, while a partially visible bookshelf adds depth to the scene. A single light source from the right creates a soft, cozy atmosphere, enhancing the vintage feel of her attire. The muted color palette and gentle lighting contribute to a sense of refinement and poise, evoking a feeling of exclusivity and quiet grace. The overall impression is one of timeless beauty and understated luxury.
- output:
    url: images/2026-01-28_15-45-41.png
  text: >-
    Testing With QLoRA: Melanie Laurent with a glowing aura, sphinx with ancient runes, islands floating effortlessly, towering pyramids emitting a soft glow, dusk, magical realism, ((highly detailed) ), egyptian clothes
- output:
    url: images/2026-01-28_15-59-50.png
  text: >-
    Testing Without QLoRA: Melanie Laurent with a glowing aura, sphinx with ancient runes, islands floating effortlessly, towering pyramids emitting a soft glow, dusk, magical realism, ((highly detailed) ), egyptian clothes
instance_prompt: Melanie Laurent, lora, flux
license: mit
base_model:
- black-forest-labs/FLUX.1-dev
datasets:
- je-suis-tm/melanie_laurent_lora_flux_nf4
---

# Melanie Laurent Lora Flux

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

This a non-quantized version of [https://huggingface.co/je-suis-tm/melanie_laurent_lora_flux_nf4](https://huggingface.co/je-suis-tm/melanie_laurent_lora_flux_nf4). Both are trained on the same dataset. The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py). The training took 3 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
    export MODEL_NAME="black-forest-labs/FLUX.1-dev"
    export INSTANCE_DIR="/pvol/melanie_laurent"
    export OUTPUT_DIR="/pvol/melanie_laurent_lora_flux"
    accelerate config default
    accelerate launch train_dreambooth_lora_flux1.py \
      --pretrained_model_name_or_path=$MODEL_NAME  \
      --mixed_precision="bf16" \
      --dataset_name=$INSTANCE_DIR \
      --output_dir=$OUTPUT_DIR \
      --gradient_checkpointing \
      --instance_prompt="Melanie Laurent" \
      --caption_column="text" \
      --resolution=1024 \
      --train_batch_size=1 \
      --guidance_scale=1 \
      --use_8bit_adam \
      --checkpointing_steps=100 \
      --gradient_accumulation_steps=4 \
      --optimizer="adamW" \
      --learning_rate=1e-4 \
      --lr_scheduler="constant" \
      --lr_warmup_steps=100 \
      --max_train_steps=1500 \
      --rank=4 \
      --seed="0" 
```
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/melanie_laurent_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "Melanie Laurent with a glowing aura, sphinx with ancient runes, islands floating effortlessly, towering pyramids emitting a soft glow, dusk, magical realism, ((highly detailed) ), egyptian clothes"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("melanie_laurent.png")
```

## Trigger words

You should use `Melanie Laurent` to trigger the image generation.


## Download model


[Download](/je-suis-tm/melanie_laurent_lora_flux_nf4/tree/main) them in the Files & versions tab.