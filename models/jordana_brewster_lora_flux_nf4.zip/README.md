---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-12_01-38-40.png
  text: >-
    Training With QLoRA: Jordana Brewster with long, dark brown hair cascading down her back, styled in a sophisticated and elegant setting. She wears a delicate white lace top or dress, complemented by subtle, natural makeup that highlights her features. A slight, almost imperceptible smile graces her expression. Dominating the background are large, stylized lettering in a light color, rendered with clean, modern lines and a minimalist aesthetic. The overall design evokes a sense of refinement and luxury. Jordana Brewster's attire and demeanor suggest a formal event or professional photoshoot. 
- output:
    url: images/2025-11-12_02-13-15.png
  text: >-
    Training Without QLoRA: Jordana Brewster with long, dark brown hair cascading down her back, styled in a sophisticated and elegant setting. She wears a delicate white lace top or dress, complemented by subtle, natural makeup that highlights her features. A slight, almost imperceptible smile graces her expression. Dominating the background are large, stylized lettering in a light color, rendered with clean, modern lines and a minimalist aesthetic. The overall design evokes a sense of refinement and luxury. Jordana Brewster's attire and demeanor suggest a formal event or professional photoshoot. 
- output:
    url: images/2025-11-12_03-30-05.png
  text: >-
    Testing With QLoRA: Jordana Brewster in red kimono
- output:
    url: images/2025-11-12_03-32-22.png
  text: >-
    Testing Without QLoRA: Jordana Brewster in red kimono
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Jordana Brewster, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/jordana_brewster_lora_flux_nf4
---

# Jordana Brewster Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `jordana_brewster_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0

For some unknown reasons, any woman in Flux.1-dev is at least 34C which is not the case for Jordana Brewster.

## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/jordana_brewster_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Jordana Brewster in red kimono"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("jordana_brewster_lora_flux_nf4.png")
```

## Trigger words

You should use `Jordana Brewster` to trigger the image generation.


## Download model


[Download](/je-suis-tm/jordana_brewster_lora_flux_nf4/tree/main) them in the Files & versions tab.

