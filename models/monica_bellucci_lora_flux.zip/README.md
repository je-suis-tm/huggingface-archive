---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-28_08-18-04.png
  text: >-
    Training With QLoRA: Monica Bellucci with long, dark hair cascading in loose waves down her back. Her hair is parted on the side, framing her face. Dark almond-shaped eyes in heavy black eyeliner, adorned with thick eyelashes and thick arched brows, are accentuated by heavy smokey eye makeup, including false lashes and dark eyeshadow. A hint of a smile reveals full pink lips. She dons a black jacket over a pink top, suggesting a casual yet stylish ensemble. The image's natural lighting hints at an outdoor setting, with daytime vibes. Her poised stance indicates she is posing for the photo shoot.
- output:
    url: images/2026-01-28_08-24-17.png
  text: >-
    Training Without QLoRA: Monica Bellucci with long, dark hair cascading in loose waves down her back. Her hair is parted on the side, framing her face. Dark almond-shaped eyes in heavy black eyeliner, adorned with thick eyelashes and thick arched brows, are accentuated by heavy smokey eye makeup, including false lashes and dark eyeshadow. A hint of a smile reveals full pink lips. She dons a black jacket over a pink top, suggesting a casual yet stylish ensemble. The image's natural lighting hints at an outdoor setting, with daytime vibes. Her poised stance indicates she is posing for the photo shoot.
- output:
    url: images/2026-01-28_17-00-49.png
  text: >-
    Testing With QLoRA: portrait of a beautiful mermaid called Monica Bellucci. there are a lot of small goldfish around and against the background of marine life. the light barely breaks through the water column. Cinematic, 35mm, F/2. 8, Vignette, 4k, Spotlight, Cinematic Lighting, insanely detailed and intricate, elegant, ornate, super detailed, --ar 1:2 --q 2
- output:
    url: images/2026-01-28_17-14-46.png
  text: >-
    Testing Without QLoRA: portrait of a beautiful mermaid called Monica Bellucci. there are a lot of small goldfish around and against the background of marine life. the light barely breaks through the water column. Cinematic, 35mm, F/2. 8, Vignette, 4k, Spotlight, Cinematic Lighting, insanely detailed and intricate, elegant, ornate, super detailed, --ar 1:2 --q 2
instance_prompt: Monica Bellucci, lora, flux
license: mit
base_model:
- black-forest-labs/FLUX.1-dev
datasets:
- je-suis-tm/monica_bellucci_lora_flux_nf4
---

# Monica Bellucci Lora Flux

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

This a non-quantized version of [https://huggingface.co/je-suis-tm/monica_bellucci_lora_flux_nf4](https://huggingface.co/je-suis-tm/monica_bellucci_lora_flux_nf4). Both are trained on the same dataset. The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py). The training took 3 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
    export MODEL_NAME="black-forest-labs/FLUX.1-dev"
    export INSTANCE_DIR="/pvol/monica_bellucci"
    export OUTPUT_DIR="/pvol/monica_bellucci_lora_flux"
    accelerate config default
    accelerate launch train_dreambooth_lora_flux1.py \
      --pretrained_model_name_or_path=$MODEL_NAME  \
      --mixed_precision="bf16" \
      --dataset_name=$INSTANCE_DIR \
      --output_dir=$OUTPUT_DIR \
      --gradient_checkpointing \
      --instance_prompt="Monica Bellucci" \
      --caption_column="text" \
      --resolution=1024 \
      --train_batch_size=1 \
      --guidance_scale=1 \
      --use_8bit_adam \
      --checkpointing_steps=100 \
      --gradient_accumulation_steps=4 \
      --optimizer="adamW" \
      --learning_rate=1e-4 \
      --lr_scheduler="constant" \
      --lr_warmup_steps=100 \
      --max_train_steps=1500 \
      --rank=4 \
      --seed="0" 
```
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/monica_bellucci_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "portrait of a beautiful mermaid called Monica Bellucci. there are a lot of small goldfish around and against the background of marine life. the light barely breaks through the water column. Cinematic, 35mm, F/2. 8, Vignette, 4k, Spotlight, Cinematic Lighting, insanely detailed and intricate, elegant, ornate, super detailed, --ar 1:2 --q 2"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("monica_bellucci.png")
```

## Trigger words

You should use `Monica Bellucci` to trigger the image generation.


## Download model


[Download](/je-suis-tm/monica_bellucci_lora_flux_nf4/tree/main) them in the Files & versions tab.