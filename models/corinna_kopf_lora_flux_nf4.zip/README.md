---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-01_23-26-30.png
  text: >-
    Training With QLoRA: Corinna Kopf stands centrally in a nighttime scene, likely at an amusement park or carnival. Her head is turned to the right, and she has long, blonde hair styled in braided pigtails. Though her face is blurred, she appears to wear subtle makeup and maintains a neutral expression. The background bursts with the vibrant energy of the event, dominated by a large Ferris wheel in the top-right corner. Other illuminated rides, possibly a roller coaster or drop tower, add to the lively atmosphere. The scene evokes a feeling of excitement and joy, capturing a moment of fun and activity. The woman acts as a quiet focal point, contrasting with the bustling, colorful spectacle behind her, creating a compelling visual narrative.
- output:
    url: images/2025-11-02_00-19-00.png
  text: >-
    Training Without QLoRA: Corinna Kopf stands centrally in a nighttime scene, likely at an amusement park or carnival. Her head is turned to the right, and she has long, blonde hair styled in braided pigtails. Though her face is blurred, she appears to wear subtle makeup and maintains a neutral expression. The background bursts with the vibrant energy of the event, dominated by a large Ferris wheel in the top-right corner. Other illuminated rides, possibly a roller coaster or drop tower, add to the lively atmosphere. The scene evokes a feeling of excitement and joy, capturing a moment of fun and activity. The woman acts as a quiet focal point, contrasting with the bustling, colorful spectacle behind her, creating a compelling visual narrative.
- output:
    url: images/2025-11-01_23-41-17.png
  text: >-
    Testing With QLoRA: Witch, Corinna Kopf, dark, highly detailed, hyper-realistic masterpiece, character design, volumetric lighting, fairy lights, intricate detail, ultra-realistic, hdr. --ar 9:16
- output:
    url: images/2025-11-02_00-33-06.png
  text: >-
    Testing Without QLoRA: Witch, Corinna Kopf, dark, highly detailed, hyper-realistic masterpiece, character design, volumetric lighting, fairy lights, intricate detail, ultra-realistic, hdr. --ar 9:16
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Corinna Kopf, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/corinna_kopf_lora_flux_nf4
---

# Corinna Kopf Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `corinna_kopf_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/corinna_kopf_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Witch, Corinna Kopf, dark, highly detailed, hyper-realistic masterpiece, character design, volumetric lighting, fairy lights, intricate detail, ultra-realistic, hdr. --ar 9:16"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("corinna_kopf_lora_flux_nf4.png")
```

## Trigger words

You should use `Corinna Kopf` to trigger the image generation.


## Download model


[Download](/je-suis-tm/corinna_kopf_lora_flux_nf4/tree/main) them in the Files & versions tab.
