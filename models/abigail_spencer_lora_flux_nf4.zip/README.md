---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-02_14-15-36.png
  text: >-
    Training With QLoRA: Abigail Spencer stands poised before a vibrant red backdrop emblazoned with the repeated logo. She's dressed in a sleek black dress layered with a black leather jacket, her long, dark hair completing the stylish look. The striking red background strongly suggest she's attending an awards ceremony or formal event. The image conveys a sense of occasion and recognition, hinting at a significant moment for the woman pictured.
- output:
    url: images/2025-11-02_14-49-07.png
  text: >-
    Training Without QLoRA: Abigail Spencer stands poised before a vibrant red backdrop emblazoned with the repeated logo. She's dressed in a sleek black dress layered with a black leather jacket, her long, dark hair completing the stylish look. The striking red background strongly suggest she's attending an awards ceremony or formal event. The image conveys a sense of occasion and recognition, hinting at a significant moment for the woman pictured.
- output:
    url: images/2025-11-02_14-34-24.png
  text: >-
    Testing With QLoRA: Full body view of Abigail Spencer dressed up as commanding Native Caribbean pirate captain. She is stands tall amidst the Pirate City of Lost Ships, her fierce expression and intricate tattoos reflecting chaos. Dramatic side lighting adds intensity to the scene, blending natural and futuristic elements. Wearing traditional pirate Captains Clothing and hat as depicted as Captain Jack Sparrow
- output:
    url: images/2025-11-02_15-05-46.png
  text: >-
    Testing Without QLoRA: Full body view of Abigail Spencer dressed up as commanding Native Caribbean pirate captain. She is stands tall amidst the Pirate City of Lost Ships, her fierce expression and intricate tattoos reflecting chaos. Dramatic side lighting adds intensity to the scene, blending natural and futuristic elements. Wearing traditional pirate Captains Clothing and hat as depicted as Captain Jack Sparrow
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Abigail Spencer, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/abigail_spencer_lora_flux_nf4
---

# Abigail Spencer Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `abigail_spencer_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/abigail_spencer_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Full body view of Abigail Spencer dressed up as commanding Native Caribbean pirate captain. She is stands tall amidst the Pirate City of Lost Ships, her fierce expression and intricate tattoos reflecting chaos. Dramatic side lighting adds intensity to the scene, blending natural and futuristic elements. Wearing traditional pirate Captains Clothing and hat as depicted as Captain Jack Sparrow"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("abigail_spencer_lora_flux_nf4.png")
```

## Trigger words

You should use `Abigail Spencer` to trigger the image generation.


## Download model


[Download](/je-suis-tm/abigail_spencer_lora_flux_nf4/tree/main) them in the Files & versions tab.

