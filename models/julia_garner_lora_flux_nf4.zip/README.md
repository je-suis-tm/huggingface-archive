---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-17_16-58-57.png
  text: >-
    Training With QLoRA: This close-up photograph captures Julia Garner's striking beauty and sophisticated style. She has short, loosely curled hair. She wears a stunning pink dress with thin white straps and a square neckline, embellished with delicate floral details. The dress's fitted bodice accentuates her figure. Her accessories are a key element, particularly a charming heart-shaped choker adorned with pink gemstones and matching earrings that add a touch of glamour. The jewelry complements the dress without overwhelming it. The blurred background suggests an urban setting, creating a sense of depth and a subdued atmosphere. Her confident pose and expression solidify the image as a compelling portrait, showcasing her elegance and poise. Overall, the photograph beautifully portrays her natural beauty and refined style.
- output:
    url: images/2025-11-17_17-36-56.png
  text: >-
    Training Without QLoRA: This close-up photograph captures Julia Garner's striking beauty and sophisticated style. She has short, loosely curled hair. She wears a stunning pink dress with thin white straps and a square neckline, embellished with delicate floral details. The dress's fitted bodice accentuates her figure. Her accessories are a key element, particularly a charming heart-shaped choker adorned with pink gemstones and matching earrings that add a touch of glamour. The jewelry complements the dress without overwhelming it. The blurred background suggests an urban setting, creating a sense of depth and a subdued atmosphere. Her confident pose and expression solidify the image as a compelling portrait, showcasing her elegance and poise. Overall, the photograph beautifully portrays her natural beauty and refined style.
- output:
    url: images/2025-11-17_17-27-34.png
  text: >-
    Testing With QLoRA: Julia Garner in an intricate teal and gold face shield with porcelain skin standing on a lonely desert island and surrounded by palm trees and beauty, full-view length rendering. --v 6. 1
- output:
    url: images/2025-11-17_18-02-43.png
  text: >-
    Testing Without QLoRA: Julia Garner in an intricate teal and gold face shield with porcelain skin standing on a lonely desert island and surrounded by palm trees and beauty, full-view length rendering. --v 6. 1
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Julia Garner, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/julia_garner_lora_flux_nf4
---

# Julia Garner Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `julia_garner_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/julia_garner_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Julia Garner in an intricate teal and gold face shield with porcelain skin standing on a lonely desert island and surrounded by palm trees and beauty, full-view length rendering. --v 6. 1"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("julia_garner_lora_flux_nf4.png")
```

## Trigger words

You should use `Julia Garner` to trigger the image generation.


## Download model


[Download](/je-suis-tm/julia_garner_lora_flux_nf4/tree/main) them in the Files & versions tab.

