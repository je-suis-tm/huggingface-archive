---
tags:
- text-to-image
- lora
- qlora
- flux2
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-25_11-22-34.png
  text: >-
    Training With QLoRA: Tron Ares Style, A nighttime highway scene portrays a figure in dark futuristic armor accented by striking red neon lights. the face is hidden by shiny black helmet. The figure is riding a motorcycle, bathed in the glow of streetlights that stretch long, dramatic shadows. in the blurry background, there is another motorcycle nearby. The overall aesthetic creates a robotic, unsettling presence, hinting at a tense and mysterious situation unfolding on the desolate road. The view is a closeup from the front of the motorcycle, only captures the torso of the rider and the upper part of the motorcycle.
- output:
    url: images/2026-01-25_11-35-28.png
  text: >-
    Training With QLoRA: Tron Ares Style, a dark cybernetic motorcycle with red neon lights dominates the frame, its sleek design popping against a blurry background. The vibrant red is accented by black seat and handlebars, creating a striking contrast. A closeup highlights the front wheel's bold red lit rim and black spokes. The bike's frame echoes the red hue, contributing to a dynamic, almost aggressive aesthetic. The rider is wearing neon-lit helmet and white jacket. The dark setting hints at nighttime riding with the background in dynamic blur, emphasizing the bike's intense neon-lit color.
- output:
    url: images/2026-01-25_11-44-09.png
  text: >-
    Training With QLoRA: Tron Ares Style, side view of A lone black motorcycle sits bathed in neon red glow on a deserted city street. Facing left, it's framed by a vibrant red neon wall stretching along the road. The background is a hazy cityscape of buildings and a sidewalk, all softened by the darkness. An eerie stillness hangs in the air, hinting at a silent, unsettling scene.
- output:
    url: images/2026-01-25_11-48-26.png
  text: >-
    Training With QLoRA: Tron Ares Style, a digital user interface captures nighttime city street scene rendered in cyberpunk style. The primary subject is an orange glowing car analyzed in wireframe, the car is in the middle of a wet road, highlighted with digital overlays and red lines, conveying an alert status. Cars are parked on either side of the road, with blurred details suggesting motion or low-light conditions. Buildings line the street, also in grayscale, with visible signs and streetlights adding to the urban environment. The perspective is a forward-facing view from behind the car, slightly low to the ground. Digital readouts and data streams, in red, are overlaid throughout the image, including `PROXIMITY ALERT` and other numerical data, which adds a futuristic feel. The color palette is dominated by grayscale with accents of orange and red, suggesting a high tech atmosphere, and digital glitches further enhance the image's technological theme.
- output:
    url: images/2026-01-25_12-48-41.png
  text: >-
    Training With QLoRA: Tron Ares Style, A pulse pounding jetski ride scene! Two figures in dark, red-accented dark armor are caught mid thrill, suspended at different heights on the track. The surroundings are blurred, lost in the dimly lit tunnel's orange glow. A dark, smoky atmosphere hangs heavy, with wisps of smoke adding to the unsettling, chaotic energy. It's a moment of exhilarating, the blurry background showcasing the speed.
- output:
    url: images/2026-01-25_13-14-32.png
  text: >-
    Training With QLoRA: Tron Ares Style, A dynamic action shot captures a man in a futuristic setting, appearing to move at high speed. The man is clad in a dark, form fitting armor highlighted with red accents. He is in a sprinting position, implying rapid movement, with his arms forward. Energy trails, rendered as streaks of bright blue light, emanate from his body, creating a sense of speed and motion blur. He is positioned on the right side of the frame, moving left to right in a profile view. The setting appears to be a modern office environment, with a blurred background featuring glass walls, a table with chairs, and screens displaying logos. The lighting is bright, with a cool palette of blues and the red accents of his suit, contrasting with the warmer tones from the background. The style is cinematic, with a focus on dramatic action and technological aesthetics.
- output:
    url: images/2026-01-25_17-43-44.png
  text: >-
    Training Without QLoRA: Tron Ares Style, A nighttime highway scene portrays a figure in dark futuristic armor accented by striking red neon lights. the face is hidden by shiny black helmet. The figure is riding a motorcycle, bathed in the glow of streetlights that stretch long, dramatic shadows. in the blurry background, there is another motorcycle nearby. The overall aesthetic creates a robotic, unsettling presence, hinting at a tense and mysterious situation unfolding on the desolate road. The view is a closeup from the front of the motorcycle, only captures the torso of the rider and the upper part of the motorcycle.
- output:
    url: images/2026-01-25_17-56-30.png
  text: >-
    Training Without QLoRA: Tron Ares Style, a dark cybernetic motorcycle with red neon lights dominates the frame, its sleek design popping against a blurry background. The vibrant red is accented by black seat and handlebars, creating a striking contrast. A closeup highlights the front wheel's bold red lit rim and black spokes. The bike's frame echoes the red hue, contributing to a dynamic, almost aggressive aesthetic. The rider is wearing neon-lit helmet and white jacket. The dark setting hints at nighttime riding with the background in dynamic blur, emphasizing the bike's intense neon-lit color.
- output:
    url: images/2026-01-25_18-04-59.png
  text: >-
    Training Without QLoRA: Tron Ares Style, side view of A lone black motorcycle sits bathed in neon red glow on a deserted city street. Facing left, it's framed by a vibrant red neon wall stretching along the road. The background is a hazy cityscape of buildings and a sidewalk, all softened by the darkness. An eerie stillness hangs in the air, hinting at a silent, unsettling scene.
- output:
    url: images/2026-01-25_18-09-13.png
  text: >-
    Training Without QLoRA: Tron Ares Style, a digital user interface captures nighttime city street scene rendered in cyberpunk style. The primary subject is an orange glowing car analyzed in wireframe, the car is in the middle of a wet road, highlighted with digital overlays and red lines, conveying an alert status. Cars are parked on either side of the road, with blurred details suggesting motion or low-light conditions. Buildings line the street, also in grayscale, with visible signs and streetlights adding to the urban environment. The perspective is a forward-facing view from behind the car, slightly low to the ground. Digital readouts and data streams, in red, are overlaid throughout the image, including `PROXIMITY ALERT` and other numerical data, which adds a futuristic feel. The color palette is dominated by grayscale with accents of orange and red, suggesting a high tech atmosphere, and digital glitches further enhance the image's technological theme.
- output:
    url: images/2026-01-25_19-08-44.png
  text: >-
    Training Without QLoRA: Tron Ares Style, A pulse pounding jetski ride scene! Two figures in dark, red-accented dark armor are caught mid thrill, suspended at different heights on the track. The surroundings are blurred, lost in the dimly lit tunnel's orange glow. A dark, smoky atmosphere hangs heavy, with wisps of smoke adding to the unsettling, chaotic energy. It's a moment of exhilarating, the blurry background showcasing the speed.
- output:
    url: images/2026-01-25_19-34-16.png
  text: >-
    Training Without QLoRA: Tron Ares Style, A dynamic action shot captures a man in a futuristic setting, appearing to move at high speed. The man is clad in a dark, form fitting armor highlighted with red accents. He is in a sprinting position, implying rapid movement, with his arms forward. Energy trails, rendered as streaks of bright blue light, emanate from his body, creating a sense of speed and motion blur. He is positioned on the right side of the frame, moving left to right in a profile view. The setting appears to be a modern office environment, with a blurred background featuring glass walls, a table with chairs, and screens displaying logos. The lighting is bright, with a cool palette of blues and the red accents of his suit, contrasting with the warmer tones from the background. The style is cinematic, with a focus on dramatic action and technological aesthetics.
- output:
    url: images/2026-01-26_04-12-33.png
  text: >-
    Testing With QLoRA: Tron Ares Style, this image depicts a futuristic factory interior at night, a dark and mysterious metal structure adorned with intricate geometric patterns. Embedded LED lights and varied light sources create a warm, diffused glow against a palette of grays, and browns, punctuated by vibrant orange columns. The overall mood is futuristic and intriguing, evoking a sense of depth and mystery inside a factory.
- output:
    url: images/2026-01-26_04-21-09.png
  text: >-
    Testing With QLoRA: Tron Ares Style, the image shows a group of people in black armor with red neon lights traversing a vast staircase crisscrossed with long, thin lines. They move purposefully, suggesting participation in an organized event or activity. The lines, possibly pathways or boundaries, create a structured environment that contrasts with their movement. The scene captures a moment of collective action, hinting at guidance and coordination within a large, open space. The view is high angle aerial view looking down on the figures.
- output:
    url: images/2026-01-26_04-38-25.png
  text: >-
    Testing With QLoRA: Tron Ares Style, two blurred motorcycles streak through a rain slicked downtown street, two searing red laser beams erupting from their tail lights, cutting through the darkness. Tall buildings loom, while parked cars and a few pedestrians populate the scene. Christmas lights twinkle amongst the tree branches overhead, a festive contrast to the urban grit. The motorcycles, embodies the city's relentless energy, a vibrant, unsettling pulse in the night.
- output:
    url: images/2026-01-26_05-17-45.png
  text: >-
    Testing Without QLoRA: Tron Ares Style, this image depicts a futuristic factory interior at night, a dark and mysterious metal structure adorned with intricate geometric patterns. Embedded LED lights and varied light sources create a warm, diffused glow against a palette of grays, and browns, punctuated by vibrant orange columns. The overall mood is futuristic and intriguing, evoking a sense of depth and mystery inside a factory.
- output:
    url: images/2026-01-26_05-26-15.png
  text: >-
    Testing Without QLoRA: Tron Ares Style, the image shows a group of people in black armor with red neon lights traversing a vast staircase crisscrossed with long, thin lines. They move purposefully, suggesting participation in an organized event or activity. The lines, possibly pathways or boundaries, create a structured environment that contrasts with their movement. The scene captures a moment of collective action, hinting at guidance and coordination within a large, open space. The view is high angle aerial view looking down on the figures.
- output:
    url: images/2026-01-26_05-43-11.png
  text: >-
    Testing Without QLoRA: Tron Ares Style, two blurred motorcycles streak through a rain slicked downtown street, two searing red laser beams erupting from their tail lights, cutting through the darkness. Tall buildings loom, while parked cars and a few pedestrians populate the scene. Christmas lights twinkle amongst the tree branches overhead, a festive contrast to the urban grit. The motorcycles, embodies the city's relentless energy, a vibrant, unsettling pulse in the night.
base_model: black-forest-labs/FLUX.2-dev
instance_prompt: Tron Ares Style, lora, qlora, flux2, nf4
license: mit
datasets:
- je-suis-tm/tron_ares_style_lora_flux2_nf4
---

# Tron Ares Style Lora Flux2 NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

Tron Ares is a movie in 2025. This QLoRA intends to replicate that futuristic style with high contrast visual centered on aggressive red tone.

The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux2.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux2.py). **Everything in this training script needs to be set at the same torch dtype** as the script was designed for unquantized version which will export in float32. The training took 14 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. To avoid running low on VRAM, **both transformers and text_encoder were quantized**. 

## Train

```
export MODEL_NAME="diffusers/FLUX.2-dev-bnb-4bit"
export INSTANCE_DIR="/pvol/tron_ares_style"
export OUTPUT_DIR="/pvol/tron_ares_style_lora_flux2_nf4"
export Q_DIR="/pvol/quantization_config.json"
accelerate config default
accelerate launch train_dreambooth_lora_flux2.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --bnb_quantization_config_path=$Q_DIR \
  --gradient_checkpointing \
  --cache_latents \
  --instance_prompt="Tron Ares style" \
  --caption_column="text" \
  --aspect_ratio_buckets="800,1920" \
  --center_crop \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --offload \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 

```
  
## Usage

```python
import torch
from transformers import Mistral3ForConditionalGeneration

from diffusers import Flux2Pipeline, Flux2Transformer2DModel

repo_id = "diffusers/FLUX.2-dev-bnb-4bit"
device = "cuda:0"
torch_dtype = torch.float32 #only supports float32 when using train_dreambooth_lora_flux2.py 

transformer = Flux2Transformer2DModel.from_pretrained(
  repo_id, subfolder="transformer", torch_dtype=torch_dtype, device_map="cuda:0"
)
text_encoder = Mistral3ForConditionalGeneration.from_pretrained(
  repo_id, subfolder="text_encoder", dtype=torch_dtype, device_map="cuda:0"
)

pipe = Flux2Pipeline.from_pretrained(
  repo_id, transformer=transformer, text_encoder=text_encoder, torch_dtype=torch_dtype
)
pipe.load_lora_weights("je-suis-tm/tron_ares_style_lora_flux2_nf4",
                       weight_name='pytorch_lora_weights.safetensors')
pipe.enable_model_cpu_offload()

prompt = "Tron Ares Style, two blurred motorcycles streak through a rain slicked downtown street, two searing red laser beams erupting from their tail lights, cutting through the darkness. Tall buildings loom, while parked cars and a few pedestrians populate the scene. Christmas lights twinkle amongst the tree branches overhead, a festive contrast to the urban grit. The motorcycles, embodies the city's relentless energy, a vibrant, unsettling pulse in the night."

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=800, 
  width=1920, #the movie was in a weird resolution 800*1920, the resolution needs to be divided by 16
).images[0]

image.save("tron_ares_style.png")
```

## Trigger words

You should use `Tron Ares Style` to trigger the image generation.


## Download model


[Download](/je-suis-tm/tron_ares_style_lora_flux2_nf4/tree/main) them in the Files & versions tab.

