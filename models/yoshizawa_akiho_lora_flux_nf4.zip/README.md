---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-29_15-40-35.png
  text: >-
    Training With QLoRA: The image shows Yoshizawa Akiho with dark hair, wearing headphones and a black, textured V-neck top. She gazes directly at the camera with a neutral expression, her hand gently resting on her cheek. The background, blurred but suggestive of a recording studio, reveals equipment like microphones and speakers. The scene implies she's involved in audio work, potentially recording music.
- output:
    url: images/2025-11-29_16-27-46.png
  text: >-
    Training Without QLoRA: The image shows Yoshizawa Akiho with dark hair, wearing headphones and a black, textured V-neck top. She gazes directly at the camera with a neutral expression, her hand gently resting on her cheek. The background, blurred but suggestive of a recording studio, reveals equipment like microphones and speakers. The scene implies she's involved in audio work, potentially recording music.
- output:
    url: images/2025-11-29_15-52-42.png
  text: >-
    Testing With QLoRA: Yoshizawa Akiho sitting at a dimly lit bar, enthusiastically eating a plate of chicken wings. Her face is messy with wing sauce smeared around her mouth and on her fingers. She has a look of pure enjoyment, mid-bite, with a few empty beer glasses and a basket of wings on the wooden bar counter. The background features neon signs, a rustic bar atmosphere, and a lively crowd in the distance. The lighting is warm and slightly moody, with a natural depth of field that keeps the focus on her and the food. 
- output:
    url: images/2025-11-29_16-39-15.png
  text: >-
    Testing Without QLoRA: Yoshizawa Akiho sitting at a dimly lit bar, enthusiastically eating a plate of chicken wings. Her face is messy with wing sauce smeared around her mouth and on her fingers. She has a look of pure enjoyment, mid-bite, with a few empty beer glasses and a basket of wings on the wooden bar counter. The background features neon signs, a rustic bar atmosphere, and a lively crowd in the distance. The lighting is warm and slightly moody, with a natural depth of field that keeps the focus on her and the food. 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Yoshizawa Akiho, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/yoshizawa_akiho_lora_flux_nf4
---

# Yoshizawa Akiho Lora Flux NF4

<Gallery />

吉沢明歩 / よしざわあきほ / Yoshizawa Akiho

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `yoshizawa_akiho_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1200 timesteps and the same parameters as the link mentioned above, which took around 8 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** The biggest challenge of training Japanese actresses is their photos used heavy filters to whiten and smoothen the skin. This practise severely distorts the training images which makes the result less convincing than Hollywood actresses. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/yoshizawa_akiho_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Yoshizawa Akiho sitting at a dimly lit bar, enthusiastically eating a plate of chicken wings. Her face is messy with wing sauce smeared around her mouth and on her fingers. She has a look of pure enjoyment, mid-bite, with a few empty beer glasses and a basket of wings on the wooden bar counter. The background features neon signs, a rustic bar atmosphere, and a lively crowd in the distance. The lighting is warm and slightly moody, with a natural depth of field that keeps the focus on her and the food."

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("yoshizawa_akiho_lora_flux_nf4.png")
```

## Trigger words

You should use `Yoshizawa Akiho` to trigger the image generation.


## Download model


[Download](/je-suis-tm/yoshizawa_akiho_lora_flux_nf4/tree/main) them in the Files & versions tab.

