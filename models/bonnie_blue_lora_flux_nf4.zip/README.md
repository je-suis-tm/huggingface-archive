---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-12_18-03-20.png
  text: >-
    Training With QLoRA: A striking selfie-style portrait captures Bonnie Blue, her gaze fixed directly on the viewer.The image emphasizes her natural beauty through simplicity and elegance. A dark gray wall serves as a minimalist backdrop, drawing attention to her features and creating visual depth. The composition highlights Bonnie Blue's presence, presenting a clean and sophisticated aesthetic. The overall effect is one of understated grace and a focus on her individual charm. 
- output:
    url: images/2025-11-12_18-46-41.png
  text: >-
    Training Without QLoRA: A striking selfie-style portrait captures Bonnie Blue, her gaze fixed directly on the viewer.The image emphasizes her natural beauty through simplicity and elegance. A dark gray wall serves as a minimalist backdrop, drawing attention to her features and creating visual depth. The composition highlights Bonnie Blue's presence, presenting a clean and sophisticated aesthetic. The overall effect is one of understated grace and a focus on her individual charm. 
- output:
    url: images/2025-11-12_18-33-09.png
  text: >-
    Testing With QLoRA: Dramatic cinematic style full vertical body portrait photography. Bonnie Blue is wearing a deep crimson gown. Warm golden hour lighting, soft pastel tones, professional retouching. Gentle and soothing mood, soft saturation. 
- output:
    url: images/2025-11-12_19-11-17.png
  text: >-
    Testing Without QLoRA: Dramatic cinematic style full vertical body portrait photography. Bonnie Blue is wearing a deep crimson gown. Warm golden hour lighting, soft pastel tones, professional retouching. Gentle and soothing mood, soft saturation. 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Bonnie Blue, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/bonnie_blue_lora_flux_nf4
---

# Bonnie Blue Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `bonnie_blue_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 900 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0

## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/bonnie_blue_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Dramatic cinematic style full vertical body portrait photography. Bonnie Blue is wearing a deep crimson gown. Warm golden hour lighting, soft pastel tones, professional retouching. Gentle and soothing mood, soft saturation"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("bonnie_blue_lora_flux_nf4.png")
```

## Trigger words

You should use `Bonnie Blue` to trigger the image generation.


## Download model


[Download](/je-suis-tm/bonnie_blue_lora_flux_nf4/tree/main) them in the Files & versions tab.

