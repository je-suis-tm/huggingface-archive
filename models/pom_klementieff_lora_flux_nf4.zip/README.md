---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-15_16-46-18.png
  text: >-
    Training With QLoRA: Pom Klementieff confidently poses before a striking black and red backdrop. Centrally framed, she showcases short, forward-styled hair that highlights her features. She's wearing a flowing black dress with an off the shoulder neckline and a strapless bodice, likely crafted from a delicate fabric like chiffon or organza. The dress's design incorporates playful ruffled detailing. The backdrop is primarily black, with a vibrant red section positioned to the right. The image's aesthetic suggests a formal occasion, possibly a movie premiere or awards show, lending an air of glamour and sophistication to the portrait. The composition and styling point towards a professionally captured moment, emphasizing Pom Klementieff's presence and the event's significance.
- output:
    url: images/2025-11-15_17-22-34.png
  text: >-
    Training Without QLoRA: Pom Klementieff confidently poses before a striking black and red backdrop. Centrally framed, she showcases short, forward-styled hair that highlights her features. She's wearing a flowing black dress with an off the shoulder neckline and a strapless bodice, likely crafted from a delicate fabric like chiffon or organza. The dress's design incorporates playful ruffled detailing. The backdrop is primarily black, with a vibrant red section positioned to the right. The image's aesthetic suggests a formal occasion, possibly a movie premiere or awards show, lending an air of glamour and sophistication to the portrait. The composition and styling point towards a professionally captured moment, emphasizing Pom Klementieff's presence and the event's significance.
- output:
    url: images/2025-11-15_16-59-03.png
  text: >-
    Testing With QLoRA: portrait of futuristic bionic kyborg woman resembling Pom Klementieff facing forward, front view, symetrical photo, luminescent synthesis, biopunk, sci-fi, intricate details, light abstract blur background, white, gold reflections
- output:
    url: images/2025-11-15_17-33-15.png
  text: >-
    Testing Without QLoRA: portrait of futuristic bionic kyborg woman resembling Pom Klementieff facing forward, front view, symetrical photo, luminescent synthesis, biopunk, sci-fi, intricate details, light abstract blur background, white, gold reflections
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Pom Klementieff, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/pom_klementieff_lora_flux_nf4
---

# Pom Klementieff Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `pom_klementieff_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** Flux does not seem to work well with Asian face, even Pom is half-Asian. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/pom_klementieff_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="portrait of futuristic bionic kyborg woman resembling Pom Klementieff facing forward, front view, symetrical photo, luminescent synthesis, biopunk, sci-fi, intricate details, light abstract blur background, white, gold reflections"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("pom_klementieff_lora_flux_nf4.png")
```

## Trigger words

You should use `Pom Klementieff` to trigger the image generation.


## Download model


[Download](/je-suis-tm/pom_klementieff_lora_flux_nf4/tree/main) them in the Files & versions tab.

