---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-24_16-52-51.png
  text: >-
    Training With LoRA: The image presents a portrait of Julia Garner with styled, curly hair in an updo. She's wearing a black-and-white sleeveless top, cropped to show only her upper body. The background is a stark white, indicative of a studio or indoor setting, isolating the subject and emphasizing her presence. The composition is clean and uncluttered, with no other elements visible. This deliberate simplicity, combined with the focus on Julia Garner's features, implies a professional or artistic intent, likely intended to highlight her appearance and style.
- output:
    url: images/2026-01-24_17-00-35.png
  text: >-
    Training Without LoRA: The image presents a portrait of Julia Garner with styled, curly hair in an updo. She's wearing a black-and-white sleeveless top, cropped to show only her upper body. The background is a stark white, indicative of a studio or indoor setting, isolating the subject and emphasizing her presence. The composition is clean and uncluttered, with no other elements visible. This deliberate simplicity, combined with the focus on Julia Garner's features, implies a professional or artistic intent, likely intended to highlight her appearance and style.
- output:
    url: images/2026-01-24_17-18-05.png
  text: >-
    Testing With LoRA: Julia Garner lying on a bed, almost white bedding; Bali; relax, read a BAZAAR magazine; Photo by Alexandr Tikhomirov; detailed touches; dressed beautiful pretty face with roughly skin, pretty clothes, levity; ultra realistic photo --q 2 --s 750 --v 5 --chaos 28 --v 5 --q 2
- output:
    url: images/2026-01-24_17-32-13.png
  text: >-
    Testing Without LoRA: Julia Garner lying on a bed, almost white bedding; Bali; relax, read a BAZAAR magazine; Photo by Alexandr Tikhomirov; detailed touches; dressed beautiful pretty face with roughly skin, pretty clothes, levity; ultra realistic photo --q 2 --s 750 --v 5 --chaos 28 --v 5 --q 2
instance_prompt: Julia Garner, lora, flux
license: mit
base_model:
- black-forest-labs/FLUX.1-dev
datasets:
- je-suis-tm/julia_garner_lora_flux_nf4
---

# Julia Garner Lora Flux

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

This a non-quantized version of [https://huggingface.co/je-suis-tm/julia_garner_lora_flux_nf4](https://huggingface.co/je-suis-tm/julia_garner_lora_flux_nf4). Both are trained on the same dataset. The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py). The training took 3 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/Julia Garner"
export OUTPUT_DIR="/pvol/julia_garner_lora_flux"
accelerate config default
accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="Julia Garner" \
  --caption_column="text" \
  --resolution=1024 \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/julia_garner_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "Julia Garner lying on a bed, almost white bedding; Bali; relax, read a BAZAAR magazine; Photo by Alexandr Tikhomirov; detailed touches; dressed beautiful pretty face with roughly skin, pretty clothes, levity; ultra realistic photo --q 2 --s 750 --v 5 --chaos 28 --v 5 --q 2"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("Julia Garner.png")
```

## Trigger words

You should use `Julia Garner` to trigger the image generation.


## Download model


[Download](/je-suis-tm/julia_garner_lora_flux_nf4/tree/main) them in the Files & versions tab.