---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-08_17-08-26.png
  text: >-
    Training With QLoRA: The image depicts Florence Pugh with striking features, likely at a formal event. She has blonde hair styled in relaxed, shoulder-length waves. She's wearing a sleeveless silver dress with a V-neckline, seemingly crafted from a lightweight, shimmering material like chiffon or organza, and embellished with scattered rhinestones that create a sparkling effect. A subtle, golden Oscar statuette is visible in the background, hinting at a prestigious awards ceremony or gala. The overall impression suggests the woman is being celebrated for her accomplishments within the entertainment industry, possibly having received an award.
- output:
    url: images/2025-11-08_17-49-07.png
  text: >-
    Training Without QLoRA: The image depicts Florence Pugh with striking features, likely at a formal event. She has blonde hair styled in relaxed, shoulder-length waves. She's wearing a sleeveless silver dress with a V-neckline, seemingly crafted from a lightweight, shimmering material like chiffon or organza, and embellished with scattered rhinestones that create a sparkling effect. A subtle, golden Oscar statuette is visible in the background, hinting at a prestigious awards ceremony or gala. The overall impression suggests the woman is being celebrated for her accomplishments within the entertainment industry, possibly having received an award.
- output:
    url: images/2025-11-08_17-26-53.png
  text: >-
    Testing With QLoRA: close-up portrait of an edgy street style model named Florence Pugh with neon-colored eye makeup, focusing on intense black eyeshadow, glowing orange collar of a high-tech wear jacket visible, cyberpunk-inspired hairstyle with subtle colored highlights, background showing blurred city lights at night, piercing gaze directly at the camera, skin has a cool blue tint contrasting with warm lighting from below, small red digital elements floating near the face, photorealistic --ar 9:16 --quality 2 --style raw --v 6. 1
- output:
    url: images/2025-11-08_18-04-17.png
  text: >-
    Testing Without QLoRA: close-up portrait of an edgy street style model named Florence Pugh with neon-colored eye makeup, focusing on intense black eyeshadow, glowing orange collar of a high-tech wear jacket visible, cyberpunk-inspired hairstyle with subtle colored highlights, background showing blurred city lights at night, piercing gaze directly at the camera, skin has a cool blue tint contrasting with warm lighting from below, small red digital elements floating near the face, photorealistic --ar 9:16 --quality 2 --style raw --v 6. 1
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Florence Pugh, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/florence_pugh_lora_flux_nf4
---

# Florence Pugh Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `florence_pugh_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/florence_pugh_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="close-up portrait of an edgy street style model named Florence Pugh with neon-colored eye makeup, focusing on intense black eyeshadow, glowing orange collar of a high-tech wear jacket visible, cyberpunk-inspired hairstyle with subtle colored highlights, background showing blurred city lights at night, piercing gaze directly at the camera, skin has a cool blue tint contrasting with warm lighting from below, small red digital elements floating near the face, photorealistic --ar 9:16 --quality 2 --style raw --v 6. 1"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("florence_pugh_lora_flux_nf4.png")
```

## Trigger words

You should use `Florence Pugh` to trigger the image generation.


## Download model


[Download](/je-suis-tm/florence_pugh_lora_flux_nf4/tree/main) them in the Files & versions tab.

