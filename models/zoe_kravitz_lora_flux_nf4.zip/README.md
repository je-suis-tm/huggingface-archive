---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-16_16-58-38.png
  text: >-
    Training With QLoRA: Zoe Kravitz with blonde braids and striking gold earrings poses confidently against a white wall. She's dressed in a black blazer layered over a shimmering gold top, possibly leather, adding to her glamorous appearance. Her hair is neatly styled in small braids gathered into a bun. The long, dangling gold earrings feature three large balls suspended on delicate chains. Behind her, a white wall displays the words in bold green lettering. The scene evokes a formal setting, likely a fashion photoshoot or event. Her poised stance and fashionable attire project an air of sophistication and elegance, suggesting a brand or magazine campaign.
- output:
    url: images/2025-11-16_17-38-26.png
  text: >-
    Training Without QLoRA: Zoe Kravitz with blonde braids and striking gold earrings poses confidently against a white wall. She's dressed in a black blazer layered over a shimmering gold top, possibly leather, adding to her glamorous appearance. Her hair is neatly styled in small braids gathered into a bun. The long, dangling gold earrings feature three large balls suspended on delicate chains. Behind her, a white wall displays the words in bold green lettering. The scene evokes a formal setting, likely a fashion photoshoot or event. Her poised stance and fashionable attire project an air of sophistication and elegance, suggesting a brand or magazine campaign.
- output:
    url: images/2025-11-16_21-52-32.png
  text: >-
    Testing With QLoRA: Zoe Kravitz in black suit and white shirt
- output:
    url: images/2025-11-16_21-55-54.png
  text: >-
    Testing Without QLoRA: Zoe Kravitz in black suit and white shirt
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Zoe Kravitz, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/zoe_kravitz_lora_flux_nf4
---

# Zoe Kravitz Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `zoe_kravitz_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/zoe_kravitz_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Zoe Kravitz in black suit and white shirt"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("zoe_kravitz_lora_flux_nf4.png")
```

## Trigger words

You should use `Zoe Kravitz` to trigger the image generation.


## Download model


[Download](/je-suis-tm/zoe_kravitz_lora_flux_nf4/tree/main) them in the Files & versions tab.

