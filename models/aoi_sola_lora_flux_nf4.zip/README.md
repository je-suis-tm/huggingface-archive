---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-22_15-32-18.png
  text: >-
    Training With QLoRA: The image showcases a smiling Aoi Sola holding a sign. Centered and casually posed, she is wearing a colorful summer dress set against a blurred background featuring a large logo, suggesting a promotional event. Warm tones dominate, contrasted by the white sign and blue logo details. The soft, even lighting and friendly expression create an approachable and energetic vibe, with a slightly retro, early 2000s internet aesthetic. It's clearly promotional photography for a gaming-related brand.
- output:
    url: images/2025-11-22_15-52-26.png
  text: >-
    Training Without QLoRA: The image showcases a smiling Aoi Sola holding a sign. Centered and casually posed, she is wearing a colorful summer dress set against a blurred background featuring a large logo, suggesting a promotional event. Warm tones dominate, contrasted by the white sign and blue logo details. The soft, even lighting and friendly expression create an approachable and energetic vibe, with a slightly retro, early 2000s internet aesthetic. It's clearly promotional photography for a gaming-related brand.
- output:
    url: images/2025-11-23_01-31-37.png
  text: >-
    Testing With QLoRA: A close-up 35mm film photograph of Aoi Sola sitting in a dimly lit room.  A red off-shoulder dress with intricate gold embroidery hugs her body. One hand rests delicately on her knee as she gazes directly into the camera lens. A layered gold necklace and long red earrings add to her mystique. The warm colors of the room create a moody atmosphere, while the dark background subtly blends into the shadows. The subject is the main focus, with the background blurred just enough to emphasize her beauty. High contrast between light and dark creates dramatic shadows across her face and body, making her appear almost ethereal in the photograph. 
- output:
    url: images/2025-11-23_02-05-08.png
  text: >-
    Testing Without QLoRA: A close-up 35mm film photograph of Aoi Sola sitting in a dimly lit room.  A red off-shoulder dress with intricate gold embroidery hugs her body. One hand rests delicately on her knee as she gazes directly into the camera lens. A layered gold necklace and long red earrings add to her mystique. The warm colors of the room create a moody atmosphere, while the dark background subtly blends into the shadows. The subject is the main focus, with the background blurred just enough to emphasize her beauty. High contrast between light and dark creates dramatic shadows across her face and body, making her appear almost ethereal in the photograph. 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Aoi Sola, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/aoi_sola_lora_flux_nf4
---

# Aoi Sola Lora Flux NF4

<Gallery />

蒼井そら / あおいそら / Aoi Sola

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `aoi_sola_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1200 timesteps and the same parameters as the link mentioned above, which took around 7.5 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** The biggest challenge of training Japanese actresses is their photos used heavy filters to whiten and smoothen the skin. This practise severely distorts the training images which makes the result less convincing than Hollywood actresses. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/aoi_sola_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="A close-up 35mm film photograph of Aoi Sola sitting in a dimly lit room.  A red off-shoulder dress with intricate gold embroidery hugs her body. One hand rests delicately on her knee as she gazes directly into the camera lens. A layered gold necklace and long red earrings add to her mystique. The warm colors of the room create a moody atmosphere, while the dark background subtly blends into the shadows. The subject is the main focus, with the background blurred just enough to emphasize her beauty. High contrast between light and dark creates dramatic shadows across her face and body, making her appear almost ethereal in the photograph."

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("aoi_sola_lora_flux_nf4.png")
```

## Trigger words

You should use `Aoi Sola` to trigger the image generation.


## Download model


[Download](/je-suis-tm/aoi_sola_lora_flux_nf4/tree/main) them in the Files & versions tab.

