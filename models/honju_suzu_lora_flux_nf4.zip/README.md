---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-30_14-06-18.png
  text: >-
    Training With QLoRA: Honju Suzu with long hair sits peacefully on a wooden swing, suspended by chains. She wears a yellow blouse and white floral skirt against a backdrop of a charming, rustic building of wood and stone. A vibrant green bush adds to the natural setting. The image radiates warmth and serenity, conveying a feeling of relaxation and contentment through the woman's gentle smile and tranquil surroundings.
- output:
    url: images/2025-11-30_14-52-12.png
  text: >-
    Training Without QLoRA: Honju Suzu with long hair sits peacefully on a wooden swing, suspended by chains. She wears a yellow blouse and white floral skirt against a backdrop of a charming, rustic building of wood and stone. A vibrant green bush adds to the natural setting. The image radiates warmth and serenity, conveying a feeling of relaxation and contentment through the woman's gentle smile and tranquil surroundings.
- output:
    url: images/2025-11-30_14-49-19.png
  text: >-
    Testing With QLoRA: Honju Suzu, in the style of Kodak Gold 200 --chaos 75 --ar 1:2 --raw --sref 2000549461 --profile x3fq9up --stylize 750 
- output:
    url: images/2025-11-30_15-31-58.png
  text: >-
    Testing Without QLoRA: Honju Suzu, in the style of Kodak Gold 200 --chaos 75 --ar 1:2 --raw --sref 2000549461 --profile x3fq9up --stylize 750 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Honju Suzu, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/honju_suzu_lora_flux_nf4
---

# Honju Suzu Lora Flux NF4

<Gallery />

本庄鈴 / ほんじょうすず / Honju Suzu

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `honju_suzu_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1200 timesteps and the same parameters as the link mentioned above, which took around 8 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** The biggest challenge of training Japanese actresses is their photos used heavy filters to whiten and smoothen the skin. This practise severely distorts the training images which makes the result less convincing than Hollywood actresses. This training dataset contains a lot of face closeup which makes result more aligned with her actual face. The tradeoff is the overfitting problem of QLoRA which makes model more likely to ignore the prompt. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/honju_suzu_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Honju Suzu, in the style of Kodak Gold 200 --chaos 75 --ar 1:2 --raw --sref 2000549461 --profile x3fq9up --stylize 750"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("honju_suzu_lora_flux_nf4.png")
```

## Trigger words

You should use `Honju Suzu` to trigger the image generation.


## Download model


[Download](/je-suis-tm/honju_suzu_lora_flux_nf4/tree/main) them in the Files & versions tab.

