---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-08-28_15-11-26.png
  text: >-
    Training With QLoRA: Brie Larson in a striking superhero costume is depicted in the image. She has shoulder-length, tousled hair, neatly parted on one side to reveal her ear, with a few strands softly framing her face. Her costume is a vibrant combination of red and blue, featuring a high collar and a prominent star emblem on the chest. Gold accents highlight the edges of the suit, adding a touch of regal flair. The pose and overall presentation convey a sense of readiness and anticipation, suggesting she's poised for action, whether it be taking flight or confronting a challenge. The image evokes a feeling of power and preparedness, hinting at a heroic mission about to unfold.
- output:
    url: images/2025-08-28_15-31-50.png
  text: >-
    Training Without QLoRA: Brie Larson in a striking superhero costume is depicted in the image. She has shoulder-length, tousled hair, neatly parted on one side to reveal her ear, with a few strands softly framing her face. Her costume is a vibrant combination of red and blue, featuring a high collar and a prominent star emblem on the chest. Gold accents highlight the edges of the suit, adding a touch of regal flair. The pose and overall presentation convey a sense of readiness and anticipation, suggesting she's poised for action, whether it be taking flight or confronting a challenge. The image evokes a feeling of power and preparedness, hinting at a heroic mission about to unfold.
- output:
    url: images/2025-08-28_17-43-24.png
  text: >-
    Testing With QLoRA: young egyptian queen named Brie Larson in super exposing pharoah clothes and necklace, background in ancient egyptian palace, hyper realistic, skin imperfections, flirty eyes, ultra details
- output:
    url: images/2025-08-28_17-49-37.png
  text: >-
    Testing Without QLoRA: young egyptian queen named Brie Larson in super exposing pharoah clothes and necklace, background in ancient egyptian palace, hyper realistic, skin imperfections, flirty eyes, ultra details
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Brie Larson, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/brie_larson_lora_flux_nf4
---

# Brie Larson Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `brie_larson_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/brie_larson_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="young egyptian queen named Brie Larson in super exposing pharoah clothes and necklace, background in ancient egyptian palace, hyper realistic, skin imperfections, flirty eyes, ultra details"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("brie_larson_lora_flux_nf4.png")
```

## Trigger words

You should use `Brie Larson` to trigger the image generation.


## Download model


[Download](/je-suis-tm/brie_larson_lora_flux_nf4/tree/main) them in the Files & versions tab.
