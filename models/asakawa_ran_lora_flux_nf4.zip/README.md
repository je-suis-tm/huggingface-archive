---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-28_15-29-53.png
  text: >-
    Training With QLoRA: The image features Asakawa Ran with long, dark hair, gazing directly at the camera with a neutral expression. She wears a light-colored top or dress, bathed in natural light streaming through a large window framed in brown. Tall, green trees are visible through the window, adding depth to the scene. The background is softly blurred, suggesting an indoor portrait with an outdoor view, creating a warm and inviting atmosphere.
- output:
    url: images/2025-11-28_18-40-53.png
  text: >-
    Training Without QLoRA: The image features Asakawa Ran with long, dark hair, gazing directly at the camera with a neutral expression. She wears a light-colored top or dress, bathed in natural light streaming through a large window framed in brown. Tall, green trees are visible through the window, adding depth to the scene. The background is softly blurred, suggesting an indoor portrait with an outdoor view, creating a warm and inviting atmosphere.
- output:
    url: images/2025-11-28_15-36-48.png
  text: >-
    Testing With QLoRA: portrait of Asakawa Ran, in the style of Greg Hildebrandt, feminine body, coastal landscapes, spray painted realism, hard-edge painting --chaos 75 --ar 1:2 --style raw --profile rsy6uq9 --stylize 750 --v 6. 1 
- output:
    url: images/2025-11-28_18-47-50.png
  text: >-
    Testing Without QLoRA: portrait of Asakawa Ran, in the style of Greg Hildebrandt, feminine body, coastal landscapes, spray painted realism, hard-edge painting --chaos 75 --ar 1:2 --style raw --profile rsy6uq9 --stylize 750 --v 6. 1 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Asakawa Ran, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/asakawa_ran_lora_flux_nf4
---

# Asakawa Ran Lora Flux NF4

<Gallery />

朝河蘭 / 清水優香 / 武藤蘭/ あさかわらん / Asakawa Ran

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `asakawa_ran_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1200 timesteps and the same parameters as the link mentioned above, which took around 7.5 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** The biggest challenge of training Japanese actresses is their photos used heavy filters to whiten and smoothen the skin. This practise severely distorts the training images which makes the result less convincing than Hollywood actresses. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/asakawa_ran_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="portrait of Asakawa Ran, in the style of Greg Hildebrandt, feminine body, coastal landscapes, spray painted realism, hard-edge painting --chaos 75 --ar 1:2 --style raw --profile rsy6uq9 --stylize 750 --v 6. 1"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("asakawa_ran_lora_flux_nf4.png")
```

## Trigger words

You should use `Asakawa Ran` to trigger the image generation.


## Download model


[Download](/je-suis-tm/asakawa_ran_lora_flux_nf4/tree/main) them in the Files & versions tab.

