---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-27_12-46-19.png
  text: >-
    Training With QLoRA: Tron Ares Style, the image depicts a futuristic cityscape at night, pulsing with vibrant neon lights outlining sleek, minimalist buildings and roads. The scene exudes modernity and technological advancement, creating a sense of depth and eerie silence due to the empty, well-lit streets. a white laser beam shoots from the bottom to the sky. Towering, densely packed buildings suggest a highly populated urban area, showcasing a cutting edge, high tech environment transformed by innovation.
- output:
    url: images/2026-01-27_12-50-16.png
  text: >-
    Training With QLoRA: Tron Ares Style, a figure in red lit black armor stand in the middle of the vehicle, which resembles a hovercraft or flying car. Glowing red lines accentuate its form, creating a visually arresting, futuristic aesthetic.
- output:
    url: images/2026-01-27_13-00-49.png
  text: >-
    Training With QLoRA: Tron Ares Style, The image showcases a futuristic scene with a figure in striking black suit accented by red neon lights riding a red motorcycle. Orange metal crane adds a vibrant contrast to the dark, intense atmosphere. The overall impression suggests a focused, high stakes mission, hinting at a sense of urgency and purpose. The view is a closeup at the front of the motorcycle, only captures the upper body of the rider and the motorcycle.
- output:
    url: images/2026-01-27_13-04-20.png
  text: >-
    Training With QLoRA: Tron Ares Style, a nighttime scene explodes with energy, a side view of a sleek black cybernetic motorcycle with red accents, rider in matching black armor and helmet with red accents, dominates the foreground. the motorcycle's wheels glowing ominously, generating orange light beam behind it. A towering building with lit windows looms in the background, a bare tree silhouetted before it. The image conveys a dramatic, late night atmosphere, hinting at a bustling urban environment under a dark, unsettling glow.
- output:
    url: images/2026-01-27_13-04-46.png
  text: >-
    Training With QLoRA: Tron Ares Style, a futuristic motorcycle rider streaks through a city at night. The sleek, black motorcycle dominates the foreground, its large wheel emitting a striking red glow that illuminates the rider's gear. The rider wears black helmet and white suit. A blurred cityscape of towering buildings fades into the background, punctuated by a red light trail emphasizing speed. The image evokes a high tech, cutting edge aesthetic with a dark, moody atmosphere, creating a tense and exciting scene of futuristic motion.
- output:
    url: images/2026-01-27_13-14-52.png
  text: >-
    Training With QLoRA: Tron Ares Style, A futuristic, neon lit motorcycle, resembling a light cycle, is positioned on a grid like platform. The bike is predominantly yellow and black with glowing rims and body outlines. It is oriented to the left, slightly angled, suggesting forward movement. The surrounding environment is a stark, digital landscape with a neon blue grid extending towards the horizon. The backdrop shows a dark wall with large, stylized, purple and white digital lettering, partially obscuring a series of numbers and letters. A yellow light beam radiates from tail of the bike, creating strong highlights and shadows, adding a sense of depth and contrast, and indicating a forward movement direction. The perspective is from a slightly low angle, enhancing the futuristic aesthetic. The overall style is clean, geometric, and cinematic, emphasizing digital lines and glowing effects in a sci-fi atmosphere.
- output:
    url: images/2026-01-27_13-22-28.png
  text: >-
    Training Without QLoRA: Tron Ares Style, the image depicts a futuristic cityscape at night, pulsing with vibrant neon lights outlining sleek, minimalist buildings and roads. The scene exudes modernity and technological advancement, creating a sense of depth and eerie silence due to the empty, well-lit streets. a white laser beam shoots from the bottom to the sky. Towering, densely packed buildings suggest a highly populated urban area, showcasing a cutting edge, high tech environment transformed by innovation.
- output:
    url: images/2026-01-27_13-26-14.png
  text: >-
    Training Without QLoRA: Tron Ares Style, a figure in red lit black armor stand in the middle of the vehicle, which resembles a hovercraft or flying car. Glowing red lines accentuate its form, creating a visually arresting, futuristic aesthetic.
- output:
    url: images/2026-01-27_13-36-18.png
  text: >-
    Training Without QLoRA: Tron Ares Style, The image showcases a futuristic scene with a figure in striking black suit accented by red neon lights riding a red motorcycle. Orange metal crane adds a vibrant contrast to the dark, intense atmosphere. The overall impression suggests a focused, high stakes mission, hinting at a sense of urgency and purpose. The view is a closeup at the front of the motorcycle, only captures the upper body of the rider and the motorcycle.
- output:
    url: images/2026-01-27_13-39-39.png
  text: >-
    Training Without QLoRA: Tron Ares Style, a nighttime scene explodes with energy, a side view of a sleek black cybernetic motorcycle with red accents, rider in matching black armor and helmet with red accents, dominates the foreground. the motorcycle's wheels glowing ominously, generating orange light beam behind it. A towering building with lit windows looms in the background, a bare tree silhouetted before it. The image conveys a dramatic, late night atmosphere, hinting at a bustling urban environment under a dark, unsettling glow.
- output:
    url: images/2026-01-27_13-40-04.png
  text: >-
    Training Without QLoRA: Tron Ares Style, a futuristic motorcycle rider streaks through a city at night. The sleek, black motorcycle dominates the foreground, its large wheel emitting a striking red glow that illuminates the rider's gear. The rider wears black helmet and white suit. A blurred cityscape of towering buildings fades into the background, punctuated by a red light trail emphasizing speed. The image evokes a high tech, cutting edge aesthetic with a dark, moody atmosphere, creating a tense and exciting scene of futuristic motion.
- output:
    url: images/2026-01-27_13-49-42.png
  text: >-
    Training Without QLoRA: Tron Ares Style, A futuristic, neon lit motorcycle, resembling a light cycle, is positioned on a grid like platform. The bike is predominantly yellow and black with glowing rims and body outlines. It is oriented to the left, slightly angled, suggesting forward movement. The surrounding environment is a stark, digital landscape with a neon blue grid extending towards the horizon. The backdrop shows a dark wall with large, stylized, purple and white digital lettering, partially obscuring a series of numbers and letters. A yellow light beam radiates from tail of the bike, creating strong highlights and shadows, adding a sense of depth and contrast, and indicating a forward movement direction. The perspective is from a slightly low angle, enhancing the futuristic aesthetic. The overall style is clean, geometric, and cinematic, emphasizing digital lines and glowing effects in a sci-fi atmosphere.
- output:
    url: images/2026-01-27_14-38-00.png
  text: >-
    Testing With QLoRA: Tron Ares Style, two futuristic motorcycles dominate the image, bathed in a striking red neon glow against a dark, blurred industrial background. The motorcycles have sleek design and angled position convey a sense of dynamic movement, as if poised for rapid acceleration. Two riders wear black armors and helmets accented by red neon lights. The vibrant red contrasts sharply with the darkness, creating a high tech, otherworldly ambiance. The blurred background isolates the vehicle, emphasizing its cutting edge design and hinting at high speed.
- output:
    url: images/2026-01-27_14-39-19.png
  text: >-
    Testing With QLoRA: Tron Ares Style, A striking cinematic still depicts a Korean woman with a severe, dark ponytail, her gaze fixed on the viewer. She's clad in a futuristic black armor accented with vibrant white neon. A blurred, industrial background bathed in red light hints at a high-tech, potentially dangerous environment. The image evokes mystery and intrigue, leaving the viewer to speculate about her role and the unfolding narrative, a compelling, enigmatic figure ready for action.
- output:
    url: images/2026-01-27_14-41-04.png
  text: >-
    Testing With QLoRA: Tron Ares Style, A futuristic, aircraft in the shape of arc de triomph is positioned centrally in the frame, hovering above a cityscape at night. The craft is metallic gray with red neon like accents outlining its geometric form, and it appears to be a small figure standing on the aircraft. The figure is emitting a red laser beam that extends downward towards a helicopter in the foreground. The aircraft is illuminated by the helicopter. The scene is shot from a low angle, emphasizing the imposing size of the aircraft and creating a sense of scale and power. The lighting is dramatic, with the red laser beam providing a focal point in the image. The atmosphere is suspenseful and suggests a science fiction theme, with the aircraft and cityscape contrasting in both form and color.
- output:
    url: images/2026-01-27_14-44-37.png
  text: >-
    Testing Without QLoRA: Tron Ares Style, two futuristic motorcycles dominate the image, bathed in a striking red neon glow against a dark, blurred industrial background. The motorcycles have sleek design and angled position convey a sense of dynamic movement, as if poised for rapid acceleration. Two riders wear black armors and helmets accented by red neon lights. The vibrant red contrasts sharply with the darkness, creating a high tech, otherworldly ambiance. The blurred background isolates the vehicle, emphasizing its cutting edge design and hinting at high speed.
- output:
    url: images/2026-01-27_14-45-53.png
  text: >-
    Testing Without QLoRA: Tron Ares Style, A striking cinematic still depicts a Korean woman with a severe, dark ponytail, her gaze fixed on the viewer. She's clad in a futuristic black armor accented with vibrant white neon. A blurred, industrial background bathed in red light hints at a high-tech, potentially dangerous environment. The image evokes mystery and intrigue, leaving the viewer to speculate about her role and the unfolding narrative, a compelling, enigmatic figure ready for action.
- output:
    url: images/2026-01-27_14-47-33.png
  text: >-
    Testing Without QLoRA: Tron Ares Style, A futuristic, aircraft in the shape of arc de triomph is positioned centrally in the frame, hovering above a cityscape at night. The craft is metallic gray with red neon like accents outlining its geometric form, and it appears to be a small figure standing on the aircraft. The figure is emitting a red laser beam that extends downward towards a helicopter in the foreground. The aircraft is illuminated by the helicopter. The scene is shot from a low angle, emphasizing the imposing size of the aircraft and creating a sense of scale and power. The lighting is dramatic, with the red laser beam providing a focal point in the image. The atmosphere is suspenseful and suggests a science fiction theme, with the aircraft and cityscape contrasting in both form and color.
instance_prompt: Tron Ares Style, lora, flux
license: mit
datasets:
- je-suis-tm/tron_ares_style_lora_flux
base_model:
- black-forest-labs/FLUX.1-dev
---

# Tron Ares Style Lora Flux1

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

Tron Ares is a movie in 2025. This LoRA intends to replicate that futuristic style with high contrast visual centered on aggressive red tone.

The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py). The training took 2 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/tron_ares_style"
export OUTPUT_DIR="/pvol/tron_ares_style_lora_flux"
accelerate config default
accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="Tron Ares Style" \
  --caption_column="text" \
  --resolution=800 \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
  
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/tron_ares_style_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "Tron Ares Style, A futuristic, aircraft in the shape of arc de triomph is positioned centrally in the frame, hovering above a cityscape at night. The craft is metallic gray with red neon like accents outlining its geometric form, and it appears to be a small figure standing on the aircraft. The figure is emitting a red laser beam that extends downward towards a helicopter in the foreground. The aircraft is illuminated by the helicopter. The scene is shot from a low angle, emphasizing the imposing size of the aircraft and creating a sense of scale and power. The lighting is dramatic, with the red laser beam providing a focal point in the image. The atmosphere is suspenseful and suggests a science fiction theme, with the aircraft and cityscape contrasting in both form and color"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("tron_ares_style.png")
```

## Trigger words

You should use `Tron Ares Style` to trigger the image generation.


## Download model


[Download](/je-suis-tm/tron_ares_style_lora_flux/tree/main) them in the Files & versions tab.