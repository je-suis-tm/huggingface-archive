---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-12-04_13-56-44.png
  text: >-
    Training With QLoRA: Kamiki Rei confidently poses in a white bikini, her long, wavy brown hair adorned with feathers and a matching headband. The bikini top features a textured, V neck design and a small red rectangle with Japanese characters on her white underwear. Her hands form a heart shape, highlighting her long, clear nails. The image conveys a sense of comfort and self expression.
- output:
    url: images/2025-12-04_14-45-18.png
  text: >-
    Training Without QLoRA: Kamiki Rei confidently poses in a white bikini, her long, wavy brown hair adorned with feathers and a matching headband. The bikini top features a textured, V neck design and a small red rectangle with Japanese characters on her white underwear. Her hands form a heart shape, highlighting her long, clear nails. The image conveys a sense of comfort and self expression.
- output:
    url: images/2025-12-04_14-12-42.png
  text: >-
    Testing With QLoRA: Portrait, hyper-realistic photograph, HD, 8K, high resolution, extremely detailed. Kamiki Rei with dark hair pulled back, and a gold necklace. Her outfit consists of a mint green fuzzy jacket, a pistachio V-neck blouse, and short, tight, thong-style blue capri-style shorts with glitter. On her feet, she wears high-top boots decorated with light blue sequins or beads. In one hand, she holds a shiny box, and the other is brought to her mouth, which is slightly open. The background is an underground parking lot with several cars. Photo for a professional photoshoot for a fashion magazine. Canon EOS-1D X MARK II, realistic style, HDR, HD, 4K, 8K, 32K and 64K resolution, extremely high level of detail.
- output:
    url: images/2025-12-04_14-59-40.png
  text: >-
    Testing Without QLoRA: Portrait, hyper-realistic photograph, HD, 8K, high resolution, extremely detailed. Kamiki Rei with dark hair pulled back, and a gold necklace. Her outfit consists of a mint green fuzzy jacket, a pistachio V-neck blouse, and short, tight, thong-style blue capri-style shorts with glitter. On her feet, she wears high-top boots decorated with light blue sequins or beads. In one hand, she holds a shiny box, and the other is brought to her mouth, which is slightly open. The background is an underground parking lot with several cars. Photo for a professional photoshoot for a fashion magazine. Canon EOS-1D X MARK II, realistic style, HDR, HD, 4K, 8K, 32K and 64K resolution, extremely high level of detail. 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Kamikei Rei, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/kamikei_rei_lora_flux_nf4
---

# Kamikei Rei Lora Flux NF4

<Gallery />

神木麗 / かみきれい / Kamikei Rei

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `kamikei_rei_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1200 timesteps and the same parameters as the link mentioned above, which took around 8 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** The biggest challenge of training Japanese actresses is their photos used heavy filters to whiten and smoothen the skin. This practise severely distorts the training images which makes the result less convincing than Hollywood actresses. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/kamikei_rei_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Portrait, hyper-realistic photograph, HD, 8K, high resolution, extremely detailed. Kamiki Rei with dark hair pulled back, and a gold necklace. Her outfit consists of a mint green fuzzy jacket, a pistachio V-neck blouse, and short, tight, thong-style blue capri-style shorts with glitter. On her feet, she wears high-top boots decorated with light blue sequins or beads. In one hand, she holds a shiny box, and the other is brought to her mouth, which is slightly open. The background is an underground parking lot with several cars. Photo for a professional photoshoot for a fashion magazine. Canon EOS-1D X MARK II, realistic style, HDR, HD, 4K, 8K, 32K and 64K resolution, extremely high level of detail."

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("kamikei_rei_lora_flux_nf4.png")
```

## Trigger words

You should use `Kamikei Rei` to trigger the image generation.


## Download model


[Download](/je-suis-tm/kamikei_rei_lora_flux_nf4/tree/main) them in the Files & versions tab.

