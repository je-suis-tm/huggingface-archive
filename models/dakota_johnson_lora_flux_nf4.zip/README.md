---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-11-09_18-17-39.png
  text: >-
    Training With QLoRA: Dakota Johnson with long, straight brown hair and bangs that frame her face. Her hair falls just below her shoulders. She's dressed in business attire, featuring a white collared shirt with a pointed collar standing at the back of her neck. A thin, smooth tie or scarf, potentially silk or cotton, is knotted around her neck. Over the shirt, she wears a gray, double-breasted jacket with two rows of buttons and small, round epaulets adorning the shoulders. The jacket's style and the woman's overall appearance suggest she may be dressed for a formal occasion or professional meeting.
- output:
    url: images/2025-11-09_18-53-20.png
  text: >-
    Training Without QLoRA: Dakota Johnson with long, straight brown hair and bangs that frame her face. Her hair falls just below her shoulders. She's dressed in business attire, featuring a white collared shirt with a pointed collar standing at the back of her neck. A thin, smooth tie or scarf, potentially silk or cotton, is knotted around her neck. Over the shirt, she wears a gray, double-breasted jacket with two rows of buttons and small, round epaulets adorning the shoulders. The jacket's style and the woman's overall appearance suggest she may be dressed for a formal occasion or professional meeting.
- output:
    url: images/2025-11-09_18-39-08.png
  text: >-
    Testing With QLoRA: Dramatic cinematic style full vertical body portrait photography. Dakota Johnson is wearing a deep crimson gown. Warm golden hour lighting, soft pastel tones, professional retouching. Gentle and soothing mood, soft saturation. 
- output:
    url: images/2025-11-09_20-13-54.png
  text: >-
    Testing Without QLoRA: Dramatic cinematic style full vertical body portrait photography. Dakota Johnson is wearing a deep crimson gown. Warm golden hour lighting, soft pastel tones, professional retouching. Gentle and soothing mood, soft saturation. 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Dakota Johnson, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/dakota_johnson_lora_flux_nf4
---

# Dakota Johnson Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `dakota_johnson_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/dakota_johnson_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Dramatic cinematic style full vertical body portrait photography. Dakota Johnson is wearing a deep crimson gown. Warm golden hour lighting, soft pastel tones, professional retouching. Gentle and soothing mood, soft saturation. "

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("dakota_johnson_lora_flux_nf4.png")
```

## Trigger words

You should use `Dakota Johnson` to trigger the image generation.


## Download model


[Download](/je-suis-tm/dakota_johnson_lora_flux_nf4/tree/main) them in the Files & versions tab.

