---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-23_14-38-06.png
  text: >-
    Training With LoRA: Florence Pugh exudes glamour in this image. Her platinum blonde hair is styled in a sleek, slicked-back fashion, complementing a striking black dress. The dress, seemingly crafted from sheer fabric, features delicate straps that wrap and tie at the back, creating a low-cut neckline. A gold chain necklace with a prominent pendant adds a touch of luxury, while small stud earrings complete the ensemble. The backdrop is a clean white wall accented with gray tones. Her posture and attire suggest a formal occasion, perhaps a red-carpet event. The overall impression is one of sophisticated elegance and confident style, drawing the viewer's attention to her poised presence.
- output:
    url: images/2026-01-23_14-43-26.png
  text: >-
    Training Without LoRA: Florence Pugh exudes glamour in this image. Her platinum blonde hair is styled in a sleek, slicked-back fashion, complementing a striking black dress. The dress, seemingly crafted from sheer fabric, features delicate straps that wrap and tie at the back, creating a low-cut neckline. A gold chain necklace with a prominent pendant adds a touch of luxury, while small stud earrings complete the ensemble. The backdrop is a clean white wall accented with gray tones. Her posture and attire suggest a formal occasion, perhaps a red-carpet event. The overall impression is one of sophisticated elegance and confident style, drawing the viewer's attention to her poised presence.
- output:
    url: images/2026-01-23_15-24-03.png
  text: >-
    Testing With LoRA: Portrait, hyper-realistic photograph, HD, 8K, high resolution, extremely detailed. Florence Pugh with dark hair pulled back, and a gold necklace. Her outfit consists of a mint green fuzzy jacket, a pistachio V-neck blouse, and short, tight, thong-style blue capri-style shorts with glitter. On her feet, she wears high-top boots decorated with light blue sequins or beads. In one hand, she holds a shiny box, and the other is brought to her mouth, which is slightly open. The background is an underground parking lot with several cars. Photo for a professional photoshoot for a fashion magazine. Canon EOS-1D X MARK II, realistic style, HDR, HD, 4K, 8K, 32K and 64K resolution, extremely high level of detail.
- output:
    url: images/2026-01-23_15-38-31.png
  text: >-
    Testing Without LoRA: Portrait, hyper-realistic photograph, HD, 8K, high resolution, extremely detailed. Florence Pugh with dark hair pulled back, and a gold necklace. Her outfit consists of a mint green fuzzy jacket, a pistachio V-neck blouse, and short, tight, thong-style blue capri-style shorts with glitter. On her feet, she wears high-top boots decorated with light blue sequins or beads. In one hand, she holds a shiny box, and the other is brought to her mouth, which is slightly open. The background is an underground parking lot with several cars. Photo for a professional photoshoot for a fashion magazine. Canon EOS-1D X MARK II, realistic style, HDR, HD, 4K, 8K, 32K and 64K resolution, extremely high level of detail.
instance_prompt: Florence Pugh, lora, flux
license: mit
base_model:
- black-forest-labs/FLUX.1-dev
datasets:
- je-suis-tm/florence_pugh_lora_flux_nf4
---

# Florence Pugh Lora Flux

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

This a non-quantized version of [https://huggingface.co/je-suis-tm/florence_pugh_lora_flux_nf4](https://huggingface.co/je-suis-tm/florence_pugh_lora_flux_nf4). Both are trained on the same dataset. The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py). The training took 3 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/florence_pugh"
export OUTPUT_DIR="/pvol/florence_pugh_lora_flux"
accelerate config default
accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="Florence Pugh" \
  --caption_column="text" \
  --resolution=1024 \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/florence_pugh_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "Portrait, hyper-realistic photograph, HD, 8K, high resolution, extremely detailed. Florence Pugh with dark hair pulled back, and a gold necklace. Her outfit consists of a mint green fuzzy jacket, a pistachio V-neck blouse, and short, tight, thong-style blue capri-style shorts with glitter. On her feet, she wears high-top boots decorated with light blue sequins or beads. In one hand, she holds a shiny box, and the other is brought to her mouth, which is slightly open. The background is an underground parking lot with several cars. Photo for a professional photoshoot for a fashion magazine. Canon EOS-1D X MARK II, realistic style, HDR, HD, 4K, 8K, 32K and 64K resolution, extremely high level of detail."

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("florence_pugh.png")
```

## Trigger words

You should use `Florence Pugh` to trigger the image generation.


## Download model


[Download](/je-suis-tm/florence_pugh_lora_flux_nf4/tree/main) them in the Files & versions tab.