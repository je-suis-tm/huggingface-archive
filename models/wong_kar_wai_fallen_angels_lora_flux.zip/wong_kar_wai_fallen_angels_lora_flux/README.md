---
tags:
- text-to-image
- lora
- flux2
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-07_13-58-36.png
  text: >-
    Training With QLoRA: WKW Style, A closeup photo of a solitary woman, red
    curls catching the neon glow, walks a rain-slicked city street at night.
    This still evokes a palpable sense of mystery. Her white blouse clings to
    her, a gold chain glints, and a black purse hangs from her shoulder. her
    gaze is fixed, resolute. The cityscape looms, a labyrinth of shadows and
    light, hinting at untold stories within its depths. A quiet intensity
    permeates the scene.
- output:
    url: images/2026-01-07_14-01-06.png
  text: >-
    Training With QLoRA: WKW Style, a woman commands the frame, her long, black
    hair and bangs drawing focus. Dark clothing is offset by a silver chain
    strap and vibrant red lips. The foreground is sharp, while a blurred
    background hints at a dimly lit tunnel with green lights and red walls. The
    overall effect is striking, emphasizing the woman's presence and a touch of
    mystery.
- output:
    url: images/2026-01-07_14-02-06.png
  text: >-
    Training With QLoRA: WKW Style, tilted view, a woman reclines on a metal
    bench inside a subway train, her dark hair framing her face. She wears a
    light dress, legs stretched out in relaxed repose, with shiny stilettos. The
    scene is solitary, the bench is empty, devoid of recent activity. The image
    evokes a quiet, introspective moment, suggesting a woman lost in thought or
    simply enjoying solitude. A sense of stillness permeates the urban setting.
- output:
    url: images/2026-01-07_14-03-37.png
  text: >-
    Training With QLoRA: WKW Style, a tilted sideview of a couple, a stadium
    swallowed by shadow at night. A man in yellow t shirt, short brown hair,
    faces a woman with long, dark hair, floral shirt, and faded jeans. They're
    caught off the court, a green wall flanking them. Distant streetlights bleed
    into the gloom. The air hangs thick with unspoken tension, a palpable
    unease. It feels like a moment poised on the edge of the argument between a
    couple.
- output:
    url: images/2026-01-07_14-08-37.png
  text: >-
    Training With QLoRA: WKW Style, a young man, dark hair, sits on the floor of
    a cafe, lost in thought. Dressed casually in an apron, polo, and khakis, he
    gazes upwards, his posture suggesting deep contemplation. Behind him,
    shelves overflow with drinks, a blue wall fading into the background. The
    scene is quiet, a fleeting moment of introspection. What is he thinking? The
    photograph offers no answers, only a silent, enigmatic portrait.
- output:
    url: images/2026-01-07_14-12-08.png
  text: >-
    Training With QLoRA: WKW Style, a smiling man stands in a shadowy hallway,
    bathed in dim green light. Dressed in a black jacket over a white tank top,
    wear a silver chain and dark sunglasses, his hair neatly styled. his gaze is
    directed downwards, hinting at something on the floor. The scene is framed
    by a wall of green wallpaper patterned with leaves, contributing to a
    mysterious and slightly unsettling atmosphere.
- output:
    url: images/2026-01-07_14-48-57.png
  text: >-
    Training Without QLoRA: WKW Style, A closeup photo of a solitary woman, red
    curls catching the neon glow, walks a rain-slicked city street at night.
    This still evokes a palpable sense of mystery. Her white blouse clings to
    her, a gold chain glints, and a black purse hangs from her shoulder. her
    gaze is fixed, resolute. The cityscape looms, a labyrinth of shadows and
    light, hinting at untold stories within its depths. A quiet intensity
    permeates the scene.
- output:
    url: images/2026-01-07_14-51-21.png
  text: >-
    Training Without QLoRA: WKW Style, a woman commands the frame, her long,
    black hair and bangs drawing focus. Dark clothing is offset by a silver
    chain strap and vibrant red lips. The foreground is sharp, while a blurred
    background hints at a dimly lit tunnel with green lights and red walls. The
    overall effect is striking, emphasizing the woman's presence and a touch of
    mystery.
- output:
    url: images/2026-01-07_14-52-18.png
  text: >-
    Training Without QLoRA: WKW Style, tilted view, a woman reclines on a metal
    bench inside a subway train, her dark hair framing her face. She wears a
    light dress, legs stretched out in relaxed repose, with shiny stilettos. The
    scene is solitary, the bench is empty, devoid of recent activity. The image
    evokes a quiet, introspective moment, suggesting a woman lost in thought or
    simply enjoying solitude. A sense of stillness permeates the urban setting.
- output:
    url: images/2026-01-07_14-53-45.png
  text: >-
    Training Without QLoRA: WKW Style, a tilted sideview of a couple, a stadium
    swallowed by shadow at night. A man in yellow t shirt, short brown hair,
    faces a woman with long, dark hair, floral shirt, and faded jeans. They're
    caught off the court, a green wall flanking them. Distant streetlights bleed
    into the gloom. The air hangs thick with unspoken tension, a palpable
    unease. It feels like a moment poised on the edge of the argument between a
    couple.
- output:
    url: images/2026-01-07_14-58-32.png
  text: >-
    Training Without QLoRA: WKW Style, a young man, dark hair, sits on the floor
    of a cafe, lost in thought. Dressed casually in an apron, polo, and khakis,
    he gazes upwards, his posture suggesting deep contemplation. Behind him,
    shelves overflow with drinks, a blue wall fading into the background. The
    scene is quiet, a fleeting moment of introspection. What is he thinking? The
    photograph offers no answers, only a silent, enigmatic portrait.
- output:
    url: images/2026-01-07_15-01-53.png
  text: >-
    Training Without QLoRA: WKW Style, a smiling man stands in a shadowy
    hallway, bathed in dim green light. Dressed in a black jacket over a white
    tank top, wear a silver chain and dark sunglasses, his hair neatly styled.
    his gaze is directed downwards, hinting at something on the floor. The scene
    is framed by a wall of green wallpaper patterned with leaves, contributing
    to a mysterious and slightly unsettling atmosphere.base_model:
    black-forest-labs/FLUX.2-dev
- output:
    url: images/2026-01-07_15-22-35.png
  text: >-
    Testing With QLoRA: WKW Style, a stark black and white still. the woman,
    pressed her face close on the table, a silent drama unfolding. Her dark hair
    spills against her shoulder. The background fades into shadow, punctuated by
    distant window light. A palpable intimacy hangs in the air, a shared
    vulnerability etched in their posture. Somber, contemplative, a moment
    suspended.
- output:
    url: images/2026-01-07_15-25-36.png
  text: >-
    Testing With QLoRA: WKW Style, a blurry view of a woman in the closeup, her
    red curls framing a contemplative gaze off camera, giving sadness vibe. she
    wears A white shirt with a dark palm leaf detail. The background, a tunnel
    with red walls and harsh fluorescent light, amplifies the dramatic mood.
    This image encapsulates a pivotal, character defining moment.
- output:
    url: images/2026-01-07_15-26-06.png
  text: >-
    Testing With QLoRA: WKW Style, a tilted view of a woman with long, dark
    hair, clad in a blue dress, stands within a subway train. Her hand reaches
    up to a metal overhead handle as she raises her chin, seemingly lost in
    thought. her eyes are obscured by her bangs. The background suggests an
    older subway train model, with indistinct windows and seats visible. The
    scene evokes a quiet, peaceful atmosphere, hinting at a solitary journey or
    a moment of reflection while waiting for her stop.
- output:
    url: images/2026-01-07_15-30-12.png
  text: >-
    Testing Without QLoRA: WKW Style, a stark black and white still. the woman,
    pressed her face close on the table, a silent drama unfolding. Her dark hair
    spills against her shoulder. The background fades into shadow, punctuated by
    distant window light. A palpable intimacy hangs in the air, a shared
    vulnerability etched in their posture. Somber, contemplative, a moment
    suspended.
- output:
    url: images/2026-01-07_15-33-04.png
  text: >-
    Testing Without QLoRA: WKW Style, a blurry view of a woman in the closeup,
    her red curls framing a contemplative gaze off camera, giving sadness vibe.
    she wears A white shirt with a dark palm leaf detail. The background, a
    tunnel with red walls and harsh fluorescent light, amplifies the dramatic
    mood. This image encapsulates a pivotal, character defining moment.
- output:
    url: images/2026-01-07_15-33-33.png
  text: >-
    Testing Without QLoRA: WKW Style, a tilted view of a woman with long, dark
    hair, clad in a blue dress, stands within a subway train. Her hand reaches
    up to a metal overhead handle as she raises her chin, seemingly lost in
    thought. her eyes are obscured by her bangs. The background suggests an
    older subway train model, with indistinct windows and seats visible. The
    scene evokes a quiet, peaceful atmosphere, hinting at a solitary journey or
    a moment of reflection while waiting for her stop.
instance_prompt: WKW style, lora, flux2
license: mit
datasets:
- je-suis-tm/wong_kar_wai_fallen_angels_lora_flux
base_model:
- black-forest-labs/FLUX.1-dev
---

# Wong Kar Wai Fallen Angels style Lora Flux1

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

Wong Kar Wai is one of my fav directors. This QLoRA intends to replicate that bold neon color tone, extreme wide angle, surreal neo-noir vibe of the movie Fallen Angels (1995).

The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py). The training took 2 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/wong_kar_wai_fallen_angels"
export OUTPUT_DIR="/pvol/wong_kar_wai_fallen_angels_lora_flux_nf4"
accelerate config default
accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="WKW style" \
  --caption_column="text" \
  --resolution=800 \
  --center_crop \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
  
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/wong_kar_wai_fallen_angels_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "WKW Style, a tilted view of a woman with long, dark
    hair, clad in a blue dress, stands within a subway train. Her hand reaches
    up to a metal overhead handle as she raises her chin, seemingly lost in
    thought. her eyes are obscured by her bangs. The background suggests an
    older subway train model, with indistinct windows and seats visible. The
    scene evokes a quiet, peaceful atmosphere, hinting at a solitary journey or
    a moment of reflection while waiting for her stop."

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=800, 
  width=1456, #the movie was in a weird resolution 1056*1912 but flux1 only supports square aspect ratio training
).images[0]

image.save("wong_kar_wai_fallen_angels.png")
```

## Trigger words

You should use `WKW style` to trigger the image generation.


## Download model


[Download](/je-suis-tm/wong_kar_wai_fallen_angels_lora_flux2_nf4/tree/main) them in the Files & versions tab.