---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-08-24_16-56-23.png
  text: >-
    Training With QLoRA: A fashion or lifestyle photograph captures Sky Bri in a sun-drenched outdoor setting. She poses confidently, showcasing a white swimsuit with a plunging neckline and stylish cutouts, complemented by a delicate silver necklace with a pendant. Her long blonde hair cascades around her. The backdrop hints at a tropical or subtropical location, with lush palm trees visible. A black metal railing provides a horizontal element behind the subject. The bright, warm lighting and overall composition suggest a daytime shoot in a pleasant climate. The image's focus is clearly on highlighting the swimsuit and accessories, presenting a stylish and aspirational aesthetic.
- output:
    url: images/2025-08-25_04-15-43.png
  text: >-
    Training Without QLoRA: A fashion or lifestyle photograph captures Sky Bri in a sun-drenched outdoor setting. She poses confidently, showcasing a white swimsuit with a plunging neckline and stylish cutouts, complemented by a delicate silver necklace with a pendant. Her long blonde hair cascades around her. The backdrop hints at a tropical or subtropical location, with lush palm trees visible. A black metal railing provides a horizontal element behind the subject. The bright, warm lighting and overall composition suggest a daytime shoot in a pleasant climate. The image's focus is clearly on highlighting the swimsuit and accessories, presenting a stylish and aspirational aesthetic.
- output:
    url: images/2025-08-26_17-57-02.png
  text: >-
    Testing With QLoRA: Sky Bri posing on a luxury yacht, stylish swimwear, ocean waves in the background, glamorous vacation vibe, capturing high-end travel content for social media.
- output:
    url: images/2025-08-26_18-09-25.png
  text: >-
    Testing Without QLoRA: Sky Bri posing on a luxury yacht, stylish swimwear, ocean waves in the background, glamorous vacation vibe, capturing high-end travel content for social media.
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Sky Bri, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/sky_bri_lora_flux_nf4
---

# Sky Bri Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `sky_bri_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** One of the issues with Sky Bri is most of her pics are from Instagram which are heavily filtered. This creates a very unrealistic skin. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/sky_bri_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Sky Bri posing on a luxury yacht, stylish swimwear, ocean waves in the background, glamorous vacation vibe, capturing high-end travel content for social media."

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("sky_bri_lora_flux_nf4.png")
```

## Trigger words

You should use `Sky Bri` to trigger the image generation.


## Download model


[Download](/je-suis-tm/sky_bri_lora_flux_nf4/tree/main) them in the Files & versions tab.
