---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-24_10-46-13.png
  text: >-
    Training With LoRA: A striking close-up captures IceSpice's face against a stark white background. Centrally positioned, she tilts her head slightly, her long, straight hair styled in loose waves with a vibrant yellow top contrasting against darker brown underneath. Her eyes gaze downwards, meeting the camera directly. A subtle gloss on her lips completes the look. The minimalist background emphasizes her features, creating a clean and focused portrait.
- output:
    url: images/2026-01-24_10-52-03.png
  text: >-
    Training Without LoRA: A striking close-up captures IceSpice's face against a stark white background. Centrally positioned, she tilts her head slightly, her long, straight hair styled in loose waves with a vibrant yellow top contrasting against darker brown underneath. Her eyes gaze downwards, meeting the camera directly. A subtle gloss on her lips completes the look. The minimalist background emphasizes her features, creating a clean and focused portrait.
- output:
    url: images/2026-01-24_11-44-55.png
  text: >-
    Testing With LoRA: A beautiful angelic woman called IceSpice with a colossal sword, white wings, and a lace outfit sitting on a throne, in the style of vintage photography, in black and white. --ar 1:2 --style raw --v 7
- output:
    url: images/2026-01-24_11-59-05.png
  text: >-
    Testing Without LoRA: A beautiful angelic woman called IceSpice with a colossal sword, white wings, and a lace outfit sitting on a throne, in the style of vintage photography, in black and white. --ar 1:2 --style raw --v 7
instance_prompt: IceSpice, lora, flux
license: mit
base_model:
- black-forest-labs/FLUX.1-dev
datasets:
- je-suis-tm/icespice_lora_flux_nf4
---

# IceSpice Lora Flux

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

This a non-quantized version of [https://huggingface.co/je-suis-tm/icespice_lora_flux_nf4](https://huggingface.co/je-suis-tm/icespice_lora_flux_nf4). Both are trained on the same dataset. The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py). The training took 3 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/icespice"
export OUTPUT_DIR="/pvol/icespice_lora_flux"
accelerate config default
accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="IceSpice" \
  --caption_column="text" \
  --resolution=1024 \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/icespice_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "A beautiful angelic woman called IceSpice with a colossal sword, white wings, and a lace outfit sitting on a throne, in the style of vintage photography, in black and white. --ar 1:2 --style raw --v 7"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("icespice.png")
```

## Trigger words

You should use `IceSpice` to trigger the image generation.


## Download model


[Download](/je-suis-tm/icespice_lora_flux_nf4/tree/main) them in the Files & versions tab.