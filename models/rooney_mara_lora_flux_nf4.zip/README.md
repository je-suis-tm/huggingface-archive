---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-10-22_20-57-12.png
  text: >-
    Training With QLoRA: Rooney Mara with a stylish, short hairstyle, including blunt-cut bangs that frame her face. She's wearing a simple gray tank top with a V-neck and sleeveless design, suggesting a lightweight fabric like cotton or polyester. The background is predominantly white and includes prominent text. The overall impression is that the image is likely a promotional or fashion-related photograph. The woman's clean, minimalist look highlights her natural features and conveys a sense of understated elegance. The styling suggests a focus on simplicity and a modern aesthetic.
- output:
    url: images/2025-10-22_21-25-17.png
  text: >-
    Training Without QLoRA: Rooney Mara with a stylish, short hairstyle, including blunt-cut bangs that frame her face. She's wearing a simple gray tank top with a V-neck and sleeveless design, suggesting a lightweight fabric like cotton or polyester. The background is predominantly white and includes prominent text. The overall impression is that the image is likely a promotional or fashion-related photograph. The woman's clean, minimalist look highlights her natural features and conveys a sense of understated elegance. The styling suggests a focus on simplicity and a modern aesthetic.
- output:
    url: images/2025-10-22_21-09-10.png
  text: >-
    Testing With QLoRA: Rooney Mara in a white kimono of cherry blossom patterns
- output:
    url: images/2025-10-22_21-36-18.png
  text: >-
    Testing Without QLoRA: Rooney Mara in a white kimono of cherry blossom patterns
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Rooney Mara, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/rooney_mara_lora_flux_nf4
---

# Rooney Mara Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `rooney_mara_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 timesteps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/rooney_mara_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Rooney Mara in a white kimono of cherry blossom patterns"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("rooney_mara_lora_flux_nf4.png")
```

## Trigger words

You should use `Rooney Mara` to trigger the image generation.


## Download model


[Download](/je-suis-tm/rooney_mara_lora_flux_nf4/tree/main) them in the Files & versions tab.
