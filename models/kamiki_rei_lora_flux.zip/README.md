---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-26_15-16-35.png
  text: >-
    Training With LoRA: Kamiki Rei poses for the camera against a vibrant background. She wears a black crop top with shoulder and chest cutouts, paired with white shorts or a skirt. Her hair is in a ponytail. Behind her, a red wall displays bold Chinese characters, alongside colorful objects like fruit or vegetables. Distant figures suggest a photo shoot or performance within a cultural or artistic setting.
- output:
    url: images/2026-02-03_04-36-51.png
  text: >-
    Training Without LoRA: Kamiki Rei poses for the camera against a vibrant background. She wears a black crop top with shoulder and chest cutouts, paired with white shorts or a skirt. Her hair is in a ponytail. Behind her, a red wall displays bold Chinese characters, alongside colorful objects like fruit or vegetables. Distant figures suggest a photo shoot or performance within a cultural or artistic setting.
- output:
    url: images/2026-01-26_15-41-23.png
  text: >-
    Testing With LoRA: female parachutist named Kamiki Rei, jumping from plane, smile, selfie, motion, full body visible, detailed skin, realistic, photo-realistic, 8k, highly detailed, full length frame, High detail RAW color art, diffused soft lighting, shallow depth of field, sharp focus, hyperrealism, cinematic lighting
- output:
    url: images/2026-01-26_15-55-55.png
  text: >-
    Testing Without LoRA: female parachutist named Kamiki Rei, jumping from plane, smile, selfie, motion, full body visible, detailed skin, realistic, photo-realistic, 8k, highly detailed, full length frame, High detail RAW color art, diffused soft lighting, shallow depth of field, sharp focus, hyperrealism, cinematic lighting
instance_prompt: Kamiki Rei, lora, flux
license: mit
base_model:
- black-forest-labs/FLUX.1-dev
datasets:
- je-suis-tm/kamiki_rei_lora_flux_nf4
---

# Kamiki Rei Lora Flux

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

This a non-quantized version of [https://huggingface.co/je-suis-tm/kamiki_rei_lora_flux_nf4](https://huggingface.co/je-suis-tm/kamiki_rei_lora_flux_nf4). Both are trained on the same dataset. The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/test_dreambooth_lora_flux.py). The training took 3 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/Kamiki Rei"
export OUTPUT_DIR="/pvol/kamiki_rei_lora_flux"
accelerate config default
accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="Kamiki Rei" \
  --caption_column="text" \
  --resolution=1024 \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/kamiki_rei_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "female parachutist named Kamiki Rei, jumping from plane, smile, selfie, motion, full body visible, detailed skin, realistic, photo-realistic, 8k, highly detailed, full length frame, High detail RAW color art, diffused soft lighting, shallow depth of field, sharp focus, hyperrealism, cinematic lighting"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("Kamiki Rei.png")
```

## Trigger words

You should use `Kamiki Rei` to trigger the image generation.


## Download model


[Download](/je-suis-tm/kamiki_rei_lora_flux_nf4/tree/main) them in the Files & versions tab.