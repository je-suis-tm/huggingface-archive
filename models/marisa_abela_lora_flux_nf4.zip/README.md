---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/c1000.png
  text: >-
    Training With QLoRA: Marisa Abela with dark hair pulled back in a low ponytail meets the viewer's gaze directly. She exudes a sophisticated edge in a black leather jacket detailed with gold stitching. The image employs a minimalist aesthetic, placing the focus entirely on the subject. A clean, white background provides a neutral canvas, eliminating distractions. Soft, even lighting creates a calm and serene atmosphere. The overall style is elegant and understated, highlighting the woman's features and the jacket's details with a simple, yet impactful presentation. The composition prioritizes clarity and a sense of quiet confidence.
- output:
    url: images/2025-08-17_22-14-15.png
  text: >-
    Training Without QLoRA: Marisa Abela with dark hair pulled back in a low ponytail meets the viewer's gaze directly. She exudes a sophisticated edge in a black leather jacket detailed with gold stitching. The image employs a minimalist aesthetic, placing the focus entirely on the subject. A clean, white background provides a neutral canvas, eliminating distractions. Soft, even lighting creates a calm and serene atmosphere. The overall style is elegant and understated, highlighting the woman's features and the jacket's details with a simple, yet impactful presentation. The composition prioritizes clarity and a sense of quiet confidence.
- output:
    url: images/2025-08-23_23-19-36.png
  text: >-
    Testing With QLoRA: Marisa Abela wears low cut spaghetti strap summer dress and smiles at camera
- output:
    url: images/2025-08-23_23-24-28.png
  text: >-
    Testing Without QLoRA: Marisa Abela wears low cut spaghetti strap summer dress and smiles at camera
- output:
    url: images/2025-08-23_23-46-24.png
  text: >-
    Testing With QLoRA: Marisa Abela, cyberpunk, night city, black hole, singularity, apocalypse, nihilism, cthuru, Krysten Ritter goth black bangs dark makeup, soft lights, depth of field, full length shot, photorealistic, cinematic, octane render, unreal engine, hyper detailed, volumetric lighting, hdr
- output:
    url: images/2025-08-23_23-48-17.png
  text: >-
    Testing Without QLoRA: Marisa Abela, cyberpunk, night city, black hole, singularity, apocalypse, nihilism, cthuru, Krysten Ritter goth black bangs dark makeup, soft lights, depth of field, full length shot, photorealistic, cinematic, octane render, unreal engine, hyper detailed, volumetric lighting, hdr
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: marisa abela, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/marisa_abela_lora_flux_nf4
---

# Marisa Abela Lora Flux NF4

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `marisa_abela_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1000 steps and the same parameters as the link mentioned above, which took around 6 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/marisa_abela_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Marisa Abela wears low cut spaghetti strap summer dress and smiles at camera"

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("marisa_abela_lora_flux_nf4.png")
```

## Trigger words

You should use `Marisa Abela` to trigger the image generation.


## Download model


[Download](/je-suis-tm/marisa_abela_lora_flux_nf4/tree/main) them in the Files & versions tab.