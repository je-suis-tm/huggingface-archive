---
tags:
- text-to-image
- lora
- qlora
- flux
- nf4
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2025-12-15_16-09-32.png
  text: >-
    Training With QLoRA: Okita Anri is depicted in a serene, blurred spa or bathroom setting. She wears a white towel draped over her shoulder, gazing directly at the camera. Her dark hair is styled in an elegant updo, accented by a silver barrette with pearls or rhinestones. The image captures a private, relaxing moment, focusing on her shoulders and upper chest, creating an intimate and tranquil atmosphere.
- output:
    url: images/2025-12-15_17-15-02.png
  text: >-
    Training Without QLoRA: Okita Anri is depicted in a serene, blurred spa or bathroom setting. She wears a white towel draped over her shoulder, gazing directly at the camera. Her dark hair is styled in an elegant updo, accented by a silver barrette with pearls or rhinestones. The image captures a private, relaxing moment, focusing on her shoulders and upper chest, creating an intimate and tranquil atmosphere.
- output:
    url: images/2025-12-15_16-34-19.png
  text: >-
    Testing With QLoRA: Glacier beauty. Beautiful colors. Okita Anri stands on a frozen lake, dressed in a dvr dulcesa onepiece made of ral kntarmr fabric, radiating a mysterious allure. The open knit design over her toned stomach reveals fragments of skin, allowing icy light to shine through. She has long straight hair as she stares intently into the camera, the reflection of the glaciers creating a surreal mirror effect. 
- output:
    url: images/2025-12-15_17-38-01.png
  text: >-
    Testing Without QLoRA: Glacier beauty. Beautiful colors. Okita Anri stands on a frozen lake, dressed in a dvr dulcesa onepiece made of ral kntarmr fabric, radiating a mysterious allure. The open knit design over her toned stomach reveals fragments of skin, allowing icy light to shine through. She has long straight hair as she stares intently into the camera, the reflection of the glaciers creating a surreal mirror effect. 
base_model: black-forest-labs/FLUX.1-dev
instance_prompt: Okita Anri, lora, qlora, flux, nf4
license: mit
datasets:
- je-suis-tm/okita_anri_lora_flux_nf4
---

# Okita Anri Lora Flux NF4

<Gallery />

沖田杏梨 / おきたあんり / Okita Anri

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

The QLoRA fine-tuning process of `okita_anri_lora_flux_nf4` takes inspiration from [this post (https://huggingface.co/blog/flux-qlora)](https://huggingface.co/blog/flux-qlora). The training was executed on a local computer with 1200 timesteps and the same parameters as the link mentioned above, which took around 8 hours on 8GB VRAM 4060. The peak VRAM usage was around 7.7GB. To avoid running low on VRAM, **both transformers and text_encoder were quantized.** The biggest challenge of training Japanese actresses is their photos used heavy filters to whiten and smoothen the skin. This practise severely distorts the training images which makes the result less convincing than Hollywood actresses. This training dataset contains a lot of face closeup which makes result more aligned with her actual face. The tradeoff is the overfitting problem of QLoRA which makes model more likely to ignore the prompt. All the images generated here are using the below parameters

* Height: 512
* Width: 512
* Guidance scale: 5
* Num inference steps: 20
* Max sequence length: 512
* Seed: 0
  
## Usage

```python
import torch
from diffusers import FluxPipeline, FluxTransformer2DModel
from transformers import T5EncoderModel

text_encoder_4bit = T5EncoderModel.from_pretrained(
    "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="text_encoder_2",torch_dtype=torch.float16,)

transformer_4bit = FluxTransformer2DModel.from_pretrained(
        "hf-internal-testing/flux.1-dev-nf4-pkg", subfolder="transformer",torch_dtype=torch.float16,)

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.float16,
                                    transformer=transformer_4bit,text_encoder_2=text_encoder_4bit)

pipe.load_lora_weights("je-suis-tm/okita_anri_lora_flux_nf4",
                       weight_name='pytorch_lora_weights.safetensors')

prompt="Glacier beauty. Beautiful colors. Okita Anri stands on a frozen lake, dressed in a dvr dulcesa onepiece made of ral kntarmr fabric, radiating a mysterious allure. The open knit design over her toned stomach reveals fragments of skin, allowing icy light to shine through. She has long straight hair as she stares intently into the camera, the reflection of the glaciers creating a surreal mirror effect."

image = pipe(
            prompt,
            height=512,
            width=512,
            guidance_scale=5,
            num_inference_steps=20,
            max_sequence_length=512,
            generator=torch.Generator("cpu").manual_seed(0),            
        ).images[0]

image.save("okita_anri_lora_flux_nf4.png")
```

## Trigger words

You should use `Okita Anri` to trigger the image generation.


## Download model


[Download](/je-suis-tm/okita_anri_lora_flux_nf4/tree/main) them in the Files & versions tab.

