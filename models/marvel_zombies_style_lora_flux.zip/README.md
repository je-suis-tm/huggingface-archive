---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-28_14-36-43.png
  text: >-
    Training With QLoRA: Marvel Zombies Style, A lone motorcyclist with a passenger, silhouetted, speeds into a fiery sunset across a barren landscape. The sky bleeds orange and blue, punctuated by scattered clouds. Distant power and telephone poles punctuate the scene, hinting at a decaying world. The rider's form is stark against the vibrant hues, suggesting a thrilling escape. A sense of freedom and adventure permeates the image, tinged with a melancholic beauty.
- output:
    url: images/2026-01-28_14-39-22.png
  text: >-
    Training With QLoRA: Marvel Zombies Style, this image portrays a colossal cave of towering blue stone blocks, dramatically lit with vibrant, ethereal light. Irregularly stacked stones create immense scale, while orange lights on platforms punctuate the cool blue tones. A large archway dominates the background, contributing to a striking composition. numerous figures stand at the bottom left with the spaceship parked at the bottom right of the image. The style evokes fantasy, inspiring wonder and awe within a cavernous, otherworldly space.
- output:
    url: images/2026-01-28_14-39-48.png
  text: >-
    Training With QLoRA: Marvel Zombies Style, A dramatic image showcases a dark, silhouetted woman with glowing red eyes and hair flowing towards the sky, seemingly adrift amongst swirling, asteroids. A vibrant red glow illuminates her from behind, contrasting with a deep blue, cloudy sky. The scene evokes a sense of otherworldly tension and dynamic movement, hinting at a mysterious narrative. The dark, muted color palette amplifies the drama and invites contemplation.
- output:
    url: images/2026-01-28_14-44-11.png
  text: >-
    Training With QLoRA: Marvel Zombies Style, A warrior stands poised in the foreground, arms extended, wielding two upward angled swords. She stands atop a blue surface stained with blood drops. The vibrant background explodes with green and yellow hues, a darker green dominating the left. Bright highlights suggest intense light sources above the figure, creating a dynamic and potentially chaotic scene.
- output:
    url: images/2026-01-28_14-45-04.png
  text: >-
    Training With QLoRA: Marvel Zombies Style, a fierce battle unfolds! A confident ninja in black and white armor stands poised, stroke katana behind him while looking towards left. Behind him, a woman in white armor, with a machete in her hands held ready to strike. The scene crackles with tension and anticipation, a dramatic clash of light and dark. Their dynamic poses and contrasting attire amplify the action packed atmosphere, promising a brutal and energetic confrontation.
- output:
    url: images/2026-01-28_14-45-30.png
  text: >-
    Training With QLoRA: Marvel Zombies Style, the image portrays a vast, brightly lit room with a towering ceiling, likely a storage area. A sleek, modern motorcycle dominates the foreground, centered on a concrete floor. two rows of SUVs and motorcycles in the background. Harsh fluorescent lights lining the walls create an unsettlingly bright and sterile atmosphere. The scene suggests a functional space for vehicle upkeep with the intense lighting and stark environment.
- output:
    url: images/2026-01-28_14-48-13.png
  text: >-
    Training Without QLoRA: Marvel Zombies Style, A lone motorcyclist with a passenger, silhouetted, speeds into a fiery sunset across a barren landscape. The sky bleeds orange and blue, punctuated by scattered clouds. Distant power and telephone poles punctuate the scene, hinting at a decaying world. The rider's form is stark against the vibrant hues, suggesting a thrilling escape. A sense of freedom and adventure permeates the image, tinged with a melancholic beauty.
- output:
    url: images/2026-01-28_14-50-43.png
  text: >-
    Training Without QLoRA: Marvel Zombies Style, this image portrays a colossal cave of towering blue stone blocks, dramatically lit with vibrant, ethereal light. Irregularly stacked stones create immense scale, while orange lights on platforms punctuate the cool blue tones. A large archway dominates the background, contributing to a striking composition. numerous figures stand at the bottom left with the spaceship parked at the bottom right of the image. The style evokes fantasy, inspiring wonder and awe within a cavernous, otherworldly space.
- output:
    url: images/2026-01-28_14-51-08.png
  text: >-
    Training Without QLoRA: Marvel Zombies Style, A dramatic image showcases a dark, silhouetted woman with glowing red eyes and hair flowing towards the sky, seemingly adrift amongst swirling, asteroids. A vibrant red glow illuminates her from behind, contrasting with a deep blue, cloudy sky. The scene evokes a sense of otherworldly tension and dynamic movement, hinting at a mysterious narrative. The dark, muted color palette amplifies the drama and invites contemplation.
- output:
    url: images/2026-01-28_14-55-19.png
  text: >-
    Training Without QLoRA: Marvel Zombies Style, A warrior stands poised in the foreground, arms extended, wielding two upward angled swords. She stands atop a blue surface stained with blood drops. The vibrant background explodes with green and yellow hues, a darker green dominating the left. Bright highlights suggest intense light sources above the figure, creating a dynamic and potentially chaotic scene.
- output:
    url: images/2026-01-28_14-56-09.png
  text: >-
    Training Without QLoRA: Marvel Zombies Style, a fierce battle unfolds! A confident ninja in black and white armor stands poised, stroke katana behind him while looking towards left. Behind him, a woman in white armor, with a machete in her hands held ready to strike. The scene crackles with tension and anticipation, a dramatic clash of light and dark. Their dynamic poses and contrasting attire amplify the action packed atmosphere, promising a brutal and energetic confrontation.
- output:
    url: images/2026-01-28_14-56-34.png
  text: >-
    Training Without QLoRA: Marvel Zombies Style, the image portrays a vast, brightly lit room with a towering ceiling, likely a storage area. A sleek, modern motorcycle dominates the foreground, centered on a concrete floor. two rows of SUVs and motorcycles in the background. Harsh fluorescent lights lining the walls create an unsettlingly bright and sterile atmosphere. The scene suggests a functional space for vehicle upkeep with the intense lighting and stark environment.
- output:
    url: images/2026-01-28_15-20-02.png
  text: >-
    Testing With QLoRA: Marvel Zombies Style, an Aztec god with a skull face, depicted in a full-body view. He stands firmly, gazing intensely and pointing directly at the viewer, conveying a powerful sense of anger. The god wears an intricately designed headdress made of vibrant feathers and jewels, featuring ancient symbols. His elaborate armor, decorated with traditional Aztec motifs, covers his entire body, showcasing intricate details. His eyes glow a menacing red, enhancing his intimidating presence. The background is a deep, shadowy darkness, emphasizing the eerie atmosphere, with subtle glimpses of ancient ruins barely visible in the dim light. The textures of his skin and the shine of the jewels contribute an extra layer of realism, while the full-body composition emphasizes his power and stature
- output:
    url: images/2026-01-28_15-20-29.png
  text: >-
    Testing With QLoRA: Marvel Zombies Style, beautiful Asian female Vampire,  Focus on the vampires ultra detailed, long sharp bright white teeth, she has a angry mouth open expression, with high contrast, She has long black hair with bangs blowing in the wind. She has pale white skin, blood red lips, and dark sapphire blue eyes framed by long elegant eyelashes and ornate eyeshadow that compliments her eyes. She is standing at the edge of a very high balcony with no railing, she is holding the large head of a werewolf up high in front of her. She wears a long black leather duster, it is open and blowing in the wind, under the duster she wears ornate black transparent lingerie with intricate black lace, thigh high stockings with fine lace around the top of the stockings with black bow ribbons in the front, gold garters with ornate gold belt and choker and shiny black western cowboy boots with silver spurs. It is night. There are dark clouds moving in on the Reddish, purple, and Orange sunset in the background. 
- output:
    url: images/2026-01-28_15-20-55.png
  text: >-
    Testing With QLoRA: Marvel Zombies Style, Gothic Fire-Breathing winged Dragon in a stone courtyard being Roaring into the night sky
- output:
    url: images/2026-01-28_15-24-06.png
  text: >-
    Testing Without QLoRA: Marvel Zombies Style, an Aztec god with a skull face, depicted in a full-body view. He stands firmly, gazing intensely and pointing directly at the viewer, conveying a powerful sense of anger. The god wears an intricately designed headdress made of vibrant feathers and jewels, featuring ancient symbols. His elaborate armor, decorated with traditional Aztec motifs, covers his entire body, showcasing intricate details. His eyes glow a menacing red, enhancing his intimidating presence. The background is a deep, shadowy darkness, emphasizing the eerie atmosphere, with subtle glimpses of ancient ruins barely visible in the dim light. The textures of his skin and the shine of the jewels contribute an extra layer of realism, while the full-body composition emphasizes his power and stature
- output:
    url: images/2026-01-28_15-24-31.png
  text: >-
    Testing Without QLoRA: Marvel Zombies Style, beautiful Asian female Vampire,  Focus on the vampires ultra detailed, long sharp bright white teeth, she has a angry mouth open expression, with high contrast, She has long black hair with bangs blowing in the wind. She has pale white skin, blood red lips, and dark sapphire blue eyes framed by long elegant eyelashes and ornate eyeshadow that compliments her eyes. She is standing at the edge of a very high balcony with no railing, she is holding the large head of a werewolf up high in front of her. She wears a long black leather duster, it is open and blowing in the wind, under the duster she wears ornate black transparent lingerie with intricate black lace, thigh high stockings with fine lace around the top of the stockings with black bow ribbons in the front, gold garters with ornate gold belt and choker and shiny black western cowboy boots with silver spurs. It is night. There are dark clouds moving in on the Reddish, purple, and Orange sunset in the background. 
- output:
    url: images/2026-01-28_15-24-56.png
  text: >-
    Testing Without QLoRA: Marvel Zombies Style, Gothic Fire-Breathing winged Dragon in a stone courtyard being Roaring into the night sky
instance_prompt: Marvel Zombies Style, lora, flux
license: mit
datasets:
- je-suis-tm/marvel_zombies_style_lora_flux
base_model:
- black-forest-labs/FLUX.1-dev
---

# Marvel Zombies Style Lora Flux1

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

Marvel Zombies is Marvel animation series in 2025. This LoRA intends to replicate that animation style.

The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py). The training took 2 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export TMPDIR=/pvol/tmp
        export TRANSFORMERS_CACHE=/pvol/huggingface-cache
        export HF_HOME=/pvol/huggingface-home
        export MODEL_NAME="black-forest-labs/FLUX.1-dev"
        export INSTANCE_DIR="/pvol/marvel_zombies_style"
        export OUTPUT_DIR="/pvol/marvel_zombies_style_lora_flux"
        accelerate config default
        accelerate launch train_dreambooth_lora_flux1.py \
          --pretrained_model_name_or_path=$MODEL_NAME  \
          --mixed_precision="bf16" \
          --dataset_name=$INSTANCE_DIR \
          --output_dir=$OUTPUT_DIR \
          --gradient_checkpointing \
          --instance_prompt="Marvel Zombies Style" \
          --caption_column="text" \
          --resolution=720 \
          --train_batch_size=1 \
          --guidance_scale=1 \
          --use_8bit_adam \
          --checkpointing_steps=100 \
          --gradient_accumulation_steps=4 \
          --optimizer="adamW" \
          --learning_rate=1e-4 \
          --lr_scheduler="constant" \
          --lr_warmup_steps=100 \
          --max_train_steps=1500 \
          --rank=4 \
          --seed="0" 
```
  
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/marvel_zombies_style_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "Marvel Zombies Style, Gothic Fire-Breathing winged Dragon in a stone courtyard being Roaring into the night sky"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=1024, 
  width=1024,
).images[0]

image.save("marvel_zombies_style.png")
```

## Trigger words

You should use `Marvel Zombies Style` to trigger the image generation.


## Download model


[Download](/je-suis-tm/marvel_zombies_style_lora_flux/tree/main) them in the Files & versions tab.