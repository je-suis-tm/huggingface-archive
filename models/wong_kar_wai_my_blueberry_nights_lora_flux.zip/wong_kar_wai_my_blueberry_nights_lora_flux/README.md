---
tags:
- text-to-image
- lora
- flux
- diffusers
- template:diffusion-lora
widget:
- output:
    url: images/2026-01-08_16-25-31.png
  text: >-
    Training With LoRA: WKW style, a woman radiating unsettling composure. She strides from a casino, a blue dress swirling. her posture speaks of unwavering focus. Turquoise earrings gleam against pale skin, framing sharp cheekbones. The blurred background, neon lit casino, adds to the tense, foreboding atmosphere. It's a visual distillation of a character consumed by obsession, hinting at the darkness to come.
- output:
    url: images/2026-01-08_16-32-32.png
  text: >-
    Training With LoRA: WKW style, A woman, dark hair cascading, stands behind a bar, cradling a red drink. She wears a short sleeved black leopard print dress, a flash of gold light illuminates her left arm. Her right hand holds a glass of whiskey high up in the air as if she is proposing a toast. her face is obscured by the darkness. Leaning on the bar, she exudes a sad vibe. Two dark leather barstools sit nearby. The blurred background hints at a dimly lit, retro space, with leopard print details. Warm lighting and classic decor create a nostalgic, sophisticated atmosphere, suggesting a moment of melancholy.
- output:
    url: images/2026-01-08_16-33-33.png
  text: >-
    Training With LoRA: WKW style, A woman in a black lace dress stands before a jukebox, bathed in the crimson glow of nighttime industrial lights. Facing away from the camera, her dark, wavy hair frames a contemplative pose. The blurry shadowy background reveals a bar. The scene evokes a palpable sense of mystery and delicate femininity.
- output:
    url: images/2026-01-08_16-38-04.png
  text: >-
    Training With LoRA: WKW style, a woman with dark hair, in a black shirt, delicately eats a cherry from a fork extended outside the view. She'ss seated at a table alongside the window reflecting her face. The background reveals a bustling restaurant or bar setting with additional tables, chairs, and patrons. The scene conveys a relaxed atmosphere.
- output:
    url: images/2026-01-08_16-43-35.png
  text: >-
    Training With LoRA: WKW style, A woman wears yellow tshirt and a beautifully detailed straw hat, its wide brim showcasing a striking diamond pattern. Behind her, a textured tan wall meets an off white couch adorned with floral cushions. Warm, natural light streams through wooden blinds, creating a soft glow. The scene evokes a feeling of peacefulness and quiet elegance, a moment captured in gentle, inviting light.
- output:
    url: images/2026-01-08_16-48-06.png
  text: >-
    Training With LoRA: WKW style, a surveillance camera view looking down a nocturnal cafe or bar with soft blue glow, capturing a quiet moment. A woman rests her head on her arm at the counter. The scene breathes sadness, scattered plates, glasses, flowers on the floor. shelves populate the background, suggesting a curated cafe. 
- output:
    url: images/2026-01-08_16-53-08.png
  text: >-
    Training Without LoRA: WKW style, a woman radiating unsettling composure. She strides from a casino, a blue dress swirling. her posture speaks of unwavering focus. Turquoise earrings gleam against pale skin, framing sharp cheekbones. The blurred background, neon lit casino, adds to the tense, foreboding atmosphere. It's a visual distillation of a character consumed by obsession, hinting at the darkness to come.
- output:
    url: images/2026-01-08_16-59-50.png
  text: >-
    Training Without LoRA: WKW style, A woman, dark hair cascading, stands behind a bar, cradling a red drink. She wears a short sleeved black leopard print dress, a flash of gold light illuminates her left arm. Her right hand holds a glass of whiskey high up in the air as if she is proposing a toast. her face is obscured by the darkness. Leaning on the bar, she exudes a sad vibe. Two dark leather barstools sit nearby. The blurred background hints at a dimly lit, retro space, with leopard print details. Warm lighting and classic decor create a nostalgic, sophisticated atmosphere, suggesting a moment of melancholy.
- output:
    url: images/2026-01-08_17-00-47.png
  text: >-
    Training Without LoRA: WKW style, A woman in a black lace dress stands before a jukebox, bathed in the crimson glow of nighttime industrial lights. Facing away from the camera, her dark, wavy hair frames a contemplative pose. The blurry shadowy background reveals a bar. The scene evokes a palpable sense of mystery and delicate femininity.
- output:
    url: images/2026-01-08_17-05-06.png
  text: >-
    Training Without LoRA: WKW style, a woman with dark hair, in a black shirt, delicately eats a cherry from a fork extended outside the view. She'ss seated at a table alongside the window reflecting her face. The background reveals a bustling restaurant or bar setting with additional tables, chairs, and patrons. The scene conveys a relaxed atmosphere.
- output:
    url: images/2026-01-08_17-10-22.png
  text: >-
    Training Without LoRA: WKW style, A woman wears yellow tshirt and a beautifully detailed straw hat, its wide brim showcasing a striking diamond pattern. Behind her, a textured tan wall meets an off white couch adorned with floral cushions. Warm, natural light streams through wooden blinds, creating a soft glow. The scene evokes a feeling of peacefulness and quiet elegance, a moment captured in gentle, inviting light.
- output:
    url: images/2026-01-08_17-14-40.png
  text: >-
    Training Without LoRA: WKW style, a surveillance camera view looking down a nocturnal cafe or bar with soft blue glow, capturing a quiet moment. A woman rests her head on her arm at the counter. The scene breathes sadness, scattered plates, glasses, flowers on the floor. shelves populate the background, suggesting a curated cafe. 
- output:
    url: images/2026-01-08_17-29-45.png
  text: >-
    Testing With LoRA: WKW Style, The image is a collage featuring a woman against a blurred restaurant backdrop. she has short brown hair and brown eyes wears black top. The blurred interior tables, chairs, shelves softens the background, focusing attention on the woman.
- output:
    url: images/2026-01-08_17-30-45.png
  text: >-
    Testing With LoRA: WKW Style, A captivating portrait depicts a woman with short, dark hair, her gaze fixed to her right. Centrally framed, she wears a black lace top or dress. Her head is subtly angled towards the viewer. The background is softly blurred, hinting at a red wall with vertical stripes and a vibrant, patterned corner. The overall mood is contemplative and evocative.
- output:
    url: images/2026-01-08_17-32-46.png
  text: >-
    Testing With LoRA: WKW Style, A woman in a yellow dress with a lace trimmed cowboy hat poses against a weathered brick column. tan brick columns forms the backdrop, punctuated by a glimpse of a vehicle. 
- output:
    url: images/2026-01-08_17-34-53.png
  text: >-
    Testing Without LoRA: WKW Style, The image is a collage featuring a woman against a blurred restaurant backdrop. she has short brown hair and brown eyes wears black top. The blurred interior tables, chairs, shelves softens the background, focusing attention on the woman.
- output:
    url: images/2026-01-08_17-35-50.png
  text: >-
    Testing Without LoRA: WKW Style, A captivating portrait depicts a woman with short, dark hair, her gaze fixed to her right. Centrally framed, she wears a black lace top or dress. Her head is subtly angled towards the viewer. The background is softly blurred, hinting at a red wall with vertical stripes and a vibrant, patterned corner. The overall mood is contemplative and evocative.
- output:
    url: images/2026-01-08_17-37-45.png
  text: >-
    Testing Without LoRA: WKW Style, A woman in a yellow dress with a lace trimmed cowboy hat poses against a weathered brick column. tan brick columns forms the backdrop, punctuated by a glimpse of a vehicle. 
instance_prompt: WKW style, lora, flux
license: mit
datasets:
- je-suis-tm/wong_kar_wai_my_blueberry_nights_lora_flux
base_model:
- black-forest-labs/FLUX.1-dev
---

# Wong Kar Wai My Blueberry Nights style Lora Flux1

<Gallery />

All files are also archived in [https://github.com/je-suis-tm/huggingface-archive](https://github.com/je-suis-tm/huggingface-archive) in case this gets censored.

Wong Kar Wai is one of my fav directors. This LoRA intends to replicate that grainy, saturated jewel tone, dimly-lit vibe of the movie My Blueberry Nights (2007).

The training is based on [https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py](https://github.com/huggingface/diffusers/blob/main/examples/dreambooth/train_dreambooth_lora_flux.py). The training took 2 hours on A100 80GB with max VRAM consumption at 35GB. The inference consumes 36GB of VRAM. 

## Train

```
export MODEL_NAME="black-forest-labs/FLUX.1-dev"
export INSTANCE_DIR="/pvol/wong_kar_wai_my_blueberry_nights"
export OUTPUT_DIR="/pvol/wong_kar_wai_my_blueberry_nights_lora_flux_nf4"
accelerate config default
accelerate launch train_dreambooth_lora_flux1.py \
  --pretrained_model_name_or_path=$MODEL_NAME  \
  --mixed_precision="bf16" \
  --dataset_name=$INSTANCE_DIR \
  --output_dir=$OUTPUT_DIR \
  --gradient_checkpointing \
  --instance_prompt="WKW style" \
  --caption_column="text" \
  --resolution=800 \
  --center_crop \
  --train_batch_size=1 \
  --guidance_scale=1 \
  --use_8bit_adam \
  --checkpointing_steps=100 \
  --gradient_accumulation_steps=4 \
  --optimizer="adamW" \
  --learning_rate=1e-4 \
  --lr_scheduler="constant" \
  --lr_warmup_steps=100 \
  --max_train_steps=1500 \
  --rank=4 \
  --seed="0" 
```
  
## Usage

```python
import torch
from diffusers import FluxPipeline

device = "cuda:0"

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16)

pipe.load_lora_weights("je-suis-tm/wong_kar_wai_my_blueberry_nights_lora_flux",
                       weight_name='pytorch_lora_weights.safetensors')


prompt = "WKW Style, A woman in a yellow dress with a lace trimmed cowboy hat poses against a weathered brick column. tan brick columns forms the backdrop, punctuated by a glimpse of a vehicle"

image = pipe(
  prompt=prompt,
  generator=torch.Generator(device=device).manual_seed(42),
  num_inference_steps=50, # 28 is a good trade-off
  guidance_scale=4,
  height=800, 
  width=1456, #the movie was in a weird resolution 800*1912 but flux1 only supports square aspect ratio training
).images[0]

image.save("wong_kar_wai_my_blueberry_nights.png")
```

## Trigger words

You should use `WKW style` to trigger the image generation.


## Download model


[Download](/je-suis-tm/wong_kar_wai_my_blueberry_nights_lora_flux2_nf4/tree/main) them in the Files & versions tab.